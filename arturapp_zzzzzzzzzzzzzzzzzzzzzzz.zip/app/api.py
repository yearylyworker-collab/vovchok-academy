"""HTTP API + SSE live stream for the mini app (Starlette)."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import logging
import time
from pathlib import Path
from urllib.parse import parse_qsl

from sse_starlette.sse import EventSourceResponse
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, PlainTextResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from app import config, journal
from app.engines import engines as E
from app.artur import adapter as AR
from app.engines import core as C
from app.engines import indicators as I
from app.market.hub import hub

WEB = Path(__file__).resolve().parent.parent / "web"
DEMO_UID = 1   # browser preview without Telegram (only when no BOT_TOKEN configured)


def verify(init_data: str) -> dict | None:
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        h = pairs.pop("hash", "")
        check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", config.BOT_TOKEN.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(secret, check.encode(), hashlib.sha256).hexdigest(), h):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 86400:
            return None
        u = json.loads(pairs.get("user", "{}"))
        if pairs.get("start_param"):
            u["_start"] = pairs["start_param"]
        return u
    except Exception:
        return None


def who(request: Request) -> dict | None:
    init = request.headers.get("x-init-data", "") or request.query_params.get("init", "")
    if init and config.BOT_TOKEN:
        return verify(init)
    if not config.BOT_TOKEN:
        return {"id": DEMO_UID, "first_name": "Demo"}
    return None


def need_user(fn):
    async def w(request: Request):
        u = who(request)
        if not u:
            return JSONResponse({"error": "auth"}, status_code=401)
        request.state.user = u
        return await fn(request)
    return w


# ------------------------------------------------------------------ routes --
async def page(_):
    return FileResponse(WEB / "index.html", headers={"Cache-Control": "no-cache"})


@need_user
async def me(request: Request):
    u = request.state.user
    uid = int(u["id"])
    db = journal.upsert_user(uid, username=u.get("username", ""), name=u.get("first_name", ""))
    sp = str(u.get("_start") or "")
    if sp.startswith("ref_") and sp[4:].isdigit() and journal.set_referrer(uid, int(sp[4:])):
        db = journal.user(uid)
        try:
            hub.alert("ref_join:%d:%d" % (int(sp[4:]), uid))
        except Exception:  # noqa: BLE001
            pass
    st = journal.stats(uid)
    return JSONResponse({
        "id": uid, "name": u.get("first_name", ""), "lang": db.get("lang") or "ru",
        "access": bool(db.get("access")) or config.ACCESS_OPEN or uid in _admins(), "admin": uid in _admins(), "trader_id": db.get("trader_id"),
        "pending": bool(db.get("trader_id")) and not bool(db.get("access")),
        "aff_url": ref_url(uid), "reg": bool(db.get("reg_at")), "dep": float(db.get("dep_amount") or 0),
        "min_dep": config.ACCESS_MIN_DEP, "on_reg": bool(getattr(config, "ACCESS_ON_REG", False)),
        "trial_left": journal.trial_left(uid), "trial_total": int(getattr(config, "TRIAL_SIGNALS", 0) or 0), "metro": db.get("metro") is None or bool(db.get("metro")), "phone": bool(db.get("phone")),
        "stats": st, "analytics": journal.analytics(uid),
        "system": system_info(), "support": config.SUPPORT, "aff": config.AFF_URL,
        "payout_min": config.PAYOUT_MIN, "max_attempts": max(1, int(float(os.getenv("MAX_ATTEMPTS") or 3))),
        "timeframes": list(config.TIMEFRAMES), "expiries": list(config.EXPIRIES),
        "engines": E.ENGINES, "strategies": E.STRATEGIES,
    })


def system_info() -> dict:
    return {"source": hub.source, "online": hub.connected, "latency_ms": hub.latency_ms,
            "instruments": len(hub.instruments), "updated": hub.updated_at}


async def instruments(request: Request):
    m = request.query_params.get("market")
    out = []
    for i in hub.list(m):
        d = i.public()
        last = hub.last(i.id)
        d["price"] = last[0] if last else None
        d["change"] = round(hub.change_pct(i.id), 3)
        out.append(d)
    return JSONResponse({"items": out, "system": system_info()})


async def candles(request: Request):
    inst = request.query_params.get("inst", "")
    tfq = request.query_params.get("tf", "1m")
    if hub.provider:
        await hub.provider.want(inst)
    if tfq == "30m":                                   # chart-only timeframe: aggregated from M5 / M1
        src = hub.candles(inst, 300, 600) or hub.candles(inst, 60, 600)
        agg: dict = {}
        for c in src:
            st = int(c[0]) // 1800 * 1800
            a = agg.get(st)
            if a is None:
                agg[st] = [st, c[1], c[2], c[3], c[4]]
            else:
                a[2], a[3], a[4] = max(a[2], c[2]), min(a[3], c[3]), c[4]
        return JSONResponse({"inst": inst, "tf": 1800, "candles": [agg[k] for k in sorted(agg)][-150:], "source": hub.source})
    tf = config.TIMEFRAMES.get(tfq, 60)
    return JSONResponse({"inst": inst, "tf": tf, "candles": hub.candles(inst, tf, 150), "source": hub.source})


async def trends(request: Request):
    m = request.query_params.get("market")
    out = []
    for i in hub.list(m):
        cs = hub.candles(i.id, 60, 120)
        last = hub.last(i.id)
        out.append({**i.public(), "price": last[0] if last else None, "change": round(hub.change_pct(i.id), 3),
                    **E.trend_card(cs)})
    return JSONResponse({"items": out, "system": system_info()})


async def stream(request: Request):
    """SSE: live ticks of one instrument (the mini app chart)."""
    inst = request.query_params.get("inst", "")
    q = await hub.subscribe(inst)

    async def gen():
        try:
            last = hub.last(inst)
            if last:
                yield {"event": "tick", "data": json.dumps({"p": last[0], "t": last[1]})}
            while True:
                if await request.is_disconnected():
                    break
                try:
                    p, t = await asyncio.wait_for(q.get(), timeout=10)
                    yield {"event": "tick", "data": json.dumps({"p": p, "t": t})}
                except asyncio.TimeoutError:
                    yield {"event": "ping", "data": json.dumps({"online": hub.connected})}
        finally:
            hub.unsubscribe(inst, q)
    return EventSourceResponse(gen())


def _run_engine(inst, tf_name: str, engine: str, strategy: str):
    tf = config.TIMEFRAMES[tf_name]
    cs = hub.candles(inst.id, tf, 200)
    if len(cs) < 40:
        return cs, None
    if engine == "artur":
        return cs, AR.analyze(inst.id, cs, inst.payout, config.PAYOUT_MIN, tf)
    if engine == "algometric":
        res = E.algometric(cs, inst.market)
    else:
        big = next((t for t in sorted(config.TIMEFRAMES.values()) if t >= tf * 5), 900)
        res = E.aipro(cs, inst.market, strategy, hub.candles(inst.id, big, 120))
    return cs, E.decide(res, inst.payout, config.PAYOUT_MIN)


async def pulse(request: Request):
    """Live gauge: current vote balance of the chosen engine on the chosen pair (no signal is issued)."""
    q = request.query_params
    inst = hub.instruments.get(q.get("inst", ""))
    if not inst:
        return JSONResponse({"error": "unknown"}, status_code=400)
    tf_name = q.get("tf") if q.get("tf") in config.TIMEFRAMES else "1m"
    engine = q.get("engine") if q.get("engine") in E.ENGINES else config.PRIMARY_ENGINE
    strategy = q.get("strategy") if q.get("strategy") in E.STRATEGIES else "multi"
    if hub.provider:
        await hub.provider.want(inst.id)
    cs, dec = _run_engine(inst, tf_name, engine, strategy)
    last = hub.last(inst.id)
    if not dec:
        return JSONResponse({"ready": False, "candles": len(cs), "price": last[0] if last else None})
    return JSONResponse({"ready": True, "balance": dec["balance"], "votes": dec["votes"],
                         "factors": dec["factors"], "payout": round(inst.payout),
                         "price": last[0] if last else None, "change": round(hub.change_pct(inst.id), 3)})


@need_user
async def analyze(request: Request):
    u = request.state.user
    uid = int(u["id"])
    db = journal.user(uid)
    gate = _gate(uid)
    if not gate:
        return _denied()
    b = await request.json()
    inst = hub.instruments.get(b.get("inst", ""))
    if not inst:
        return JSONResponse({"error": "unknown instrument"}, status_code=400)
    tf_name = b.get("tf", "1m") if b.get("tf") in config.TIMEFRAMES else "1m"
    exp_name = b.get("expiry", "1m") if b.get("expiry") in config.EXPIRIES else "1m"
    engine = b.get("engine") if b.get("engine") in E.ENGINES else config.PRIMARY_ENGINE
    strategy = b.get("strategy", "multi") if b.get("strategy") in E.STRATEGIES else "multi"
    amount = max(1.0, min(10000.0, float(b.get("amount") or 10)))
    if b.get("system") == "classic":
        # КЛАССИКА = обычные (японские) свечи: AI PRO analysis, any trade time
        if engine == "artur":
            engine = "aipro"
    tf = config.TIMEFRAMES[tf_name]
    if hub.provider:
        try:
            await hub.provider.want(inst.id)
        except Exception:  # noqa: BLE001
            pass
    cs = hub.candles(inst.id, tf, 200)
    log = [f"Читаем котировки {inst.name} ({hub.source})…", f"Свечей {tf_name}: {len(cs)}"]
    if len(cs) < 40 and tf < 60 and len(hub.candles(inst.id, 60, 200)) >= 40:
        # short timeframe still filling up → analyse on M1 (honestly said in the log), entry stays on the chosen expiry
        tf, cs = 60, hub.candles(inst.id, 60, 200)
        log.append(f"История {tf_name} ещё набирается — анализ по свечам M1 ({len(cs)})")
    if len(cs) < 40:
        journal.log_attempt(uid, inst, engine, "data", "data", f"{len(cs)} свечей")
        return JSONResponse({"signal": None, "log": log + ["Недостаточно истории для анализа"],
                             "no_signal_reason": "Мало данных — подождите, график прогревается"})
    if engine == "artur":
        dec = AR.analyze(inst.id, cs, inst.payout, config.PAYOUT_MIN, tf)
    else:
        if engine == "algometric":
            res = E.algometric(cs, inst.market)
        else:
            big = next((t for t in sorted(config.TIMEFRAMES.values()) if t >= tf * 5), 300)
            res = E.aipro(cs, inst.market, strategy, hub.candles(inst.id, big, 120))
        dec = E.decide(res, inst.payout, config.PAYOUT_MIN)
    log += [f"{x['name']}: {x['text']}" for x in dec["factors"]] + [x["text"] for x in dec["filters"] if x]
    if not dec["direction"] and os.getenv("ALWAYS_SIGNAL", "true").lower() in ("1", "true", "yes", "on"):
        # the user picked the pair → always give the direction ARTUR leans to, marked by its real strength
        v = dec.get("votes") or 0
        if v == 0 and len(cs) >= 4:
            v = 1 if cs[-1][4] >= cs[-4][4] else -1
        dec["direction"] = "BUY" if v >= 0 else "SELL"
        dec["strength"] = "Слабый"
        dec["forced"] = True
        if dec.get("no_signal_reason"):
            log.append("Фильтры ARTUR: " + dec["no_signal_reason"] + " — сигнал слабый")
        dec["no_signal_reason"] = None
    if not dec["direction"]:
        journal.log_attempt(uid, inst, engine, "filter", dec.get("no_signal_key") or "weak", dec.get("no_signal_reason") or "")
        return JSONResponse({"signal": None, "log": log + ["Итог: НЕТ СИГНАЛА"], "analysis": dec,
                             "no_signal_reason": dec["no_signal_reason"]})
    log.append(f"Итог: {'ВВЕРХ' if dec['direction'] == 'BUY' else 'ВНИЗ'} · перевес {dec['votes']:+d}")
    sig = journal.create(uid, inst, engine, strategy, dec["direction"], tf_name, config.EXPIRIES[exp_name], amount, dec, delay=_entry_delay(uid))
    if b.get("system") == "artur":
        journal.set_window(sig["id"], sig["id"], 1, "artur")
        sig = journal.get(sig["id"])
    journal.log_attempt(uid, inst, engine, "issued", "ok", dec["direction"])
    _metro(sig)
    return JSONResponse({"signal": sig, "log": log, "analysis": dec, "server_time": time.time(), **_trial_spend(uid, gate)})


def _metro(sig: dict) -> None:
    """Entry countdown in the bot chat (shows over the broker's site as a notification)."""
    try:
        if (journal.user(sig["uid"]).get("metro") if journal.user(sig["uid"]).get("metro") is not None else 1):
            hub.reqs.put_nowait({"metro": sig["id"]})
    except Exception:  # noqa: BLE001
        pass


@need_user
async def signal(request: Request):
    s = journal.get(int(request.path_params["sid"]))
    if not s or s["uid"] != int(request.state.user["id"]):
        return JSONResponse({"error": "not found"}, status_code=404)
    last = hub.last(s["inst"])
    return JSONResponse({"signal": s, "price": last[0] if last else None, "server_time": time.time()})


@need_user
async def signal_active(request: Request):
    """The user's current manual signal (for coming back to the app: the trade is not lost)."""
    uid = int(request.state.user["id"])
    now = time.time()
    r = journal._db.execute("SELECT id FROM signals WHERE uid=? AND created>? AND (result IS NULL OR expires_at>?) "
                            "ORDER BY id DESC LIMIT 1", (uid, now - 900, now - 45)).fetchone()
    return JSONResponse({"signal": journal.get(r["id"]) if r else None, "server_time": now})


@need_user
async def signal_recheck(request: Request):
    """Last look a few seconds before the entry: if the chart already turned against the signal, flip it."""
    sid = int(request.path_params["sid"])
    s = journal.get(sid)
    if not s or s["uid"] != int(request.state.user["id"]):
        return JSONResponse({"error": "not found"}, status_code=404)
    from app import autofeed as _A
    flipped = False
    if _A.FLIP_ON_REVERSE and s.get("entry_price") is None and time.time() < s["entry_at"] - 1.0:
        try:
            if _A.drift_against(s["inst"], s["direction"], float(s.get("created") or s["entry_at"] - 8)):
                nd = "SELL" if s["direction"] == "BUY" else "BUY"
                journal._db.execute("UPDATE signals SET direction=? WHERE id=?", (nd, sid))
                journal._db.commit()
                flipped = True
                __import__("logging").getLogger("signal").info("SIGNAL %s %s flipped to %s before entry (stale)", sid, s["inst"], nd)
        except Exception:  # noqa: BLE001
            pass
    return JSONResponse({"direction": journal.get(sid)["direction"], "flipped": flipped})


@need_user
async def signal_verify(request: Request):
    sid = int(request.path_params["sid"])
    s = journal.get(sid)
    if not s or s["uid"] != int(request.state.user["id"]):
        return JSONResponse({"error": "not found"}, status_code=404)
    b = await request.json()
    try:
        ts = float(b.get("ts"))
    except (TypeError, ValueError):
        return JSONResponse({"error": "Укажи время открытия"}, status_code=400)
    if abs(ts - s["entry_at"]) > 180:
        return JSONResponse({"error": "Время слишком далеко от сигнала бота (больше 3 минут)"}, status_code=400)
    return JSONResponse(journal.verify(sid, ts))


@need_user
async def history(request: Request):
    uid = int(request.state.user["id"])
    return JSONResponse({"items": journal.history(uid), "stats": journal.stats(uid)})


@need_user
async def register(request: Request):
    """Mini-app funnel: user submits Trader ID → stored → admin gets an approve/reject request in the bot."""
    u = request.state.user
    uid = int(u["id"])
    b = await request.json()
    tid = str(b.get("trader_id", "")).strip()
    if not tid.isdigit() or not (3 <= len(tid) <= 15):
        return JSONResponse({"error": "bad_id"}, status_code=400)
    journal.upsert_user(uid, trader_id=tid, requested=time.time(),
                        username=u.get("username", ""), name=u.get("first_name", ""))
    res = journal.check_trader(uid, tid)            # automatic check against our partner postbacks first
    if res in ("access", "need_dep"):
        try:
            hub.reqs.put_nowait({"postback": "access" if res == "access" else "reg", "uid": uid, "amount": 0})
        except Exception:  # noqa: BLE001
            pass
        return JSONResponse({"ok": True, "pending": res != "access", "check": res})
    try:                                             # not found in the partner program → manual check by the admin
        hub.reqs.put_nowait({"uid": uid, "tid": tid, "name": u.get("first_name", ""),
                             "username": u.get("username", ""), "check": res})
    except Exception:  # noqa: BLE001
        pass
    return JSONResponse({"ok": True, "pending": True, "check": res})


@need_user
async def set_lang(request: Request):
    b = await request.json()
    lang = b.get("lang") if b.get("lang") in ("ru", "ua", "en") else "ru"
    journal.upsert_user(int(request.state.user["id"]), lang=lang)
    return JSONResponse({"ok": True, "lang": lang})


APPROACH = {"conservative": ("Консервативный", "3m"), "balanced": ("Сбалансированный", "2m"),
            "extreme": ("Экстремальный", "1m")}


@need_user
async def session_start(request: Request):
    uid = int(request.state.user["id"])
    b = await request.json()
    ap = b.get("approach") if b.get("approach") in APPROACH else "balanced"
    f = lambda k, lo, hi, d: max(lo, min(hi, float(b.get(k) or d)))
    s = journal.session_new(uid, approach=ap, market="FOREX" if b.get("market") == "FOREX" else "OTC",
                            expiry=APPROACH[ap][1], balance=f("balance", 1, 1e7, 100),
                            stake_pct=f("stake_pct", 0.5, 5, 1), goal_pct=f("goal_pct", 0.5, 100, 3),
                            loss_pct=f("loss_pct", 0.5, 100, 5), martingale=bool(b.get("martingale")))
    return JSONResponse({"session": s})


def _stake(s: dict) -> float:
    base = max(1.0, round(s["balance0"] * s["stake_pct"] / 100))
    if not s["martingale"]:
        return base
    k = 0
    for t in reversed(s["items"]):
        if t["result"] != "LOSS":
            break
        k += 1
    return max(1.0, round(base * (2 ** min(k, 4))))


@need_user
async def session_next(request: Request):
    """Stop check → pick the best instrument (payout ≥ min, AI PRO consensus) → issue the next signal."""
    uid = int(request.state.user["id"])
    b = await request.json()
    s = journal.session_get(int(b.get("id", 0)))
    if not s or s["uid"] != uid:
        return JSONResponse({"error": "not found"}, status_code=404)
    if s["status"] != "active":
        return JSONResponse({"done": True, "session": s})
    if s["pending"]:
        return JSONResponse({"wait": True, "session": s})
    goal = s["balance0"] * s["goal_pct"] / 100
    lim = s["balance0"] * s["loss_pct"] / 100
    stake = _stake(s)
    room = lim + s["pnl"]                       # how much may still be lost
    base = max(1.0, round(s["balance0"] * s["stake_pct"] / 100))
    if stake > room:                            # overlap would break the loss limit → fall back to base stake
        stake = base
    reason = ("goal" if s["pnl"] >= goal else "loss" if -s["pnl"] >= lim else
              "loss" if base > room + 1e-9 else None)
    if b.get("stop"):
        reason = "manual"
    if reason:
        journal.session_end(s["id"], reason)
        return JSONResponse({"done": True, "session": journal.session_get(s["id"])})
    cands = [i for i in hub.list(s["market"]) if i.active and i.payout >= config.PAYOUT_MIN]
    best = None
    for inst in cands[:12]:
        _cs, dec = _run_engine(inst, "1m", "aipro", "multi")
        if dec and dec["direction"] and (best is None or abs(dec["balance"]) > abs(best[1]["balance"])):
            best = (inst, dec)
    if not best:
        return JSONResponse({"searching": True, "session": s,
                             "reason": f"Ищем активы с выплатой от {config.PAYOUT_MIN:.0f}% и чётким перевесом…"})
    inst, dec = best
    sig = journal.create(uid, inst, "aipro", "multi", dec["direction"], "1m", config.EXPIRIES[s["expiry"]],
                         stake, dec, session=s["id"])
    return JSONResponse({"signal": sig, "session": journal.session_get(s["id"]), "server_time": time.time(),
                         "log": [f"{x['name']}: {x['text']}" for x in dec["factors"]]})


@need_user
async def session_view(request: Request):
    s = journal.session_get(int(request.path_params["sid"]))
    if not s or s["uid"] != int(request.state.user["id"]):
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse({"session": s})


@need_user
async def sessions(request: Request):
    L = journal.session_list(int(request.state.user["id"]))
    ended = [x for x in L if x["status"] == "ended"]
    return JSONResponse({"items": L, "count": len(ended), "pnl": round(sum(x["pnl"] for x in ended), 2)})


AUTO_TFS = ("1m", "2m", "3m", "5m")      # timeframe = expiry for the auto scanner (ARTUR engine: M1 only)


def _fresh(inst_id: str, max_age: float = 20.0) -> bool:
    last = hub.last(inst_id)
    return bool(last) and time.time() - last[1] <= max_age


@need_user
async def autosignal(request: Request):
    """ARTUR AI SIGNAL: scan every active pair (OTC + FOREX) × timeframes → issue the single cleanest setup."""
    u = request.state.user
    uid = int(u["id"])
    db = journal.user(uid)
    gate = _gate(uid)
    if not gate:
        return _denied()
    b = await request.json()
    amount = max(1.0, min(10000.0, float(b.get("amount") or 10)))
    markets = [m for m in (b.get("markets") or ["OTC", "FOREX"]) if m in ("OTC", "FOREX")] or ["OTC", "FOREX"]
    cands = [i for m in markets for i in hub.list(m) if i.active and i.payout >= config.PAYOUT_MIN]
    cands.sort(key=lambda i: -i.payout)
    # warm up a few top-payout pairs that aren't streaming yet (broker sends ~200 1m candles on subscribe)
    if hub.provider:
        cold = [i for i in cands if not _fresh(i.id)][:6]
        for i in cold:
            await hub.provider.want(i.id)
        if cold:
            await asyncio.sleep(3.5)
    ready = [i for i in cands if _fresh(i.id) and len(hub.candles(i.id, 60, 60)) >= 40]
    log = [f"Рынки: {' + '.join(markets)} · активов с выплатой от {config.PAYOUT_MIN:.0f}%: {len(cands)}",
           f"Живые котировки есть у {len(ready)} пар · таймфреймы {', '.join(AUTO_TFS)}"]
    scored, combos, why = [], 0, {}
    for inst in ready:
        for tf_name in (("1m",) if config.PRIMARY_ENGINE == "artur" else AUTO_TFS):
            tf = config.TIMEFRAMES[tf_name]
            cs = hub.candles(inst.id, tf, 200)
            if len(cs) < 40:
                continue
            combos += 1
            if config.PRIMARY_ENGINE == "artur":
                a = AR.analyze(inst.id, cs, inst.payout, config.PAYOUT_MIN, tf)
                p = a
                if not a["direction"]:
                    k = a.get("no_signal_key") or "weak"
                    why[k] = why.get(k, 0) + 1
                    continue
                score = a["score"] / 50 + (inst.payout - config.PAYOUT_MIN) / 100
                scored.append((score, inst, tf_name, a, p))
                continue
            big = next((t for t in sorted(config.TIMEFRAMES.values()) if t >= tf * 5), 900)
            a = E.decide(E.algometric(cs, inst.market), inst.payout, config.PAYOUT_MIN)
            p = E.decide(E.aipro(cs, inst.market, "multi", hub.candles(inst.id, big, 120)), inst.payout, config.PAYOUT_MIN)
            if not a["direction"] or a["direction"] != p["direction"]:
                k = a.get("no_signal_key") or p.get("no_signal_key") or "conflict"
                why[k] = why.get(k, 0) + 1
                continue
            score = abs(a["balance"]) + abs(p["balance"]) + (inst.payout - config.PAYOUT_MIN) / 100
            scored.append((score, inst, tf_name, a, p))
    scored.sort(key=lambda x: -x[0])
    mrs = {m: C.market_regime(m) for m in markets}
    best = None
    for score, inst, tf_name, a, p in scored[:6]:
        try:
            cr = C.analyze(inst, tf_name, tf_name, uid, mrs.get(inst.market))
        except Exception:  # noqa: BLE001
            continue
        if not cr.get("ready"):
            continue
        rk, fu = cr["modules"]["risk"], cr["fusion"]
        if not rk["approved"]:
            why["risk"] = why.get("risk", 0) + 1
            continue
        if fu["final"] in ("BUY", "SELL") and fu["final"] != a["direction"]:
            why["fusion"] = why.get("fusion", 0) + 1
            continue
        bonus = 0.5 if fu["final"] == a["direction"] else 0.0
        if best is None or score + bonus > best[0]:
            best = (score + bonus, inst, tf_name, a, p, cr)
    log.append(f"Проверено комбинаций пара × ТФ: {combos} · прошли движки: {len(scored)}")
    if not best:
        top = sorted(why.items(), key=lambda x: -x[1])[:3]
        names = {"weak": "факторы противоречат", "few": "мало подтверждений", "flat": "флэт", "htf": "против старшего ТФ",
                 "payout": "низкая выплата", "conflict": "ALGOMETRIC и AI PRO спорят", "risk": "RISK SHIELD", "fusion": "ARTUR FUSION против"}
        reason = ("Сейчас нет чистого сетапа ни на одной паре — лучше подождать 1–2 минуты. "
                  + ("Чаще всего: " + ", ".join(f"{names.get(k, k)} ({n})" for k, n in top) if top else ""))
        if not ready:
            reason = "Котировки ещё прогреваются — повторите через несколько секунд."
        if cands:
            journal.log_attempt(uid, cands[0], "auto", "auto", "auto_none", reason)
        return JSONResponse({"signal": None, "log": log + ["Итог: НЕТ СИГНАЛА"], "no_signal_reason": reason,
                             "scanned": len(ready), "combos": combos})
    _s, inst, tf_name, a, p, cr = best
    dec = dict(a)
    fu, rk = cr["fusion"], cr["modules"]["risk"]
    dec["factors"] = a["factors"] + [f for f in p["factors"] if f["name"] not in {x["name"] for x in a["factors"]}]
    dec["core"] = {"final": fu["final"], "consensus": fu["consensus"], "risk": rk["status"],
                   "regime": cr["summary"]["regime"], "sync": cr["summary"]["sync"],
                   "confirmed": (["ARTUR HA"] if config.PRIMARY_ENGINE == "artur" else ["ALGOMETRIC", "AI PRO"]) + [m["name"] for k, m in cr["modules"].items()
                                                            if k in ("smart_flow", "quant") and m.get("vote") == (1 if a["direction"] == "BUY" else -1)]}
    log += [f"Лучший сетап: {inst.name} · ТФ {tf_name} · выплата {inst.payout:.0f}%",
            (f"ARTUR HA: {a['direction']} · оценка качества {a.get('score', 0):.0f}/100 · режим {a.get('regime') or 'н/д'}"
             if config.PRIMARY_ENGINE == "artur" else
             f"ALGOMETRIC: {a['direction']} ({a['balance']:+.2f}) · AI PRO: {p['direction']} ({p['balance']:+.2f})"),
            f"ARTUR CORE: {fu['final']} · RISK SHIELD: SIGNAL APPROVED",
            f"Итог: {'ВВЕРХ' if a['direction'] == 'BUY' else 'ВНИЗ'} · время сделки {tf_name}"]
    sig = journal.create(uid, inst, "auto", "control_ai", a["direction"], tf_name, config.EXPIRIES[tf_name], amount, dec)
    journal.log_attempt(uid, inst, "auto", "issued", "ok", a["direction"])
    ip = inst.public()
    last = hub.last(inst.id)
    ip["price"] = last[0] if last else None
    return JSONResponse({**_trial_spend(uid, gate), "signal": sig, "inst": ip, "tf": tf_name, "expiry": tf_name, "log": log, "analysis": dec,
                         "scanned": len(ready), "combos": combos, "server_time": time.time()})


def _ref_link(uid: int) -> str | None:
    bn = config.BOT_USERNAME or journal.get_setting("bot_username") or ""
    return f"https://t.me/{bn}?start=ref_{uid}" if bn else None


@need_user
async def ref(request: Request):
    """Partner program: personal link, invited friends, rewards (all from the users table)."""
    uid = int(request.state.user["id"])
    s = journal.ref_summary(uid)
    items = [{"name": (r["name"] or "Трейдер"), "status": r["status"], "reward": r["ref_reward"] or 0,
              "date": r["ref_at"]} for r in s["items"]]
    return JSONResponse({"link": _ref_link(uid), "min_dep": config.REF_MIN_DEP, "reward": config.REF_REWARD,
                         "invited": s["invited"], "active": s["active"], "qualified": s["qualified"],
                         "earned": s["earned"], "paid": s["paid"], "due": s["due"], "items": items,
                         "payouts": s["payouts"]})


def ref_url(uid: int) -> str:
    """Personal Pocket Option registration link: the lead id comes back in the postback."""
    url = config.POCKET_REF_URL
    if not url:
        return ""
    lead = f"{config.CLICK_PREFIX}{uid}"
    if "{click}" in url:
        return url.replace("{click}", lead)
    return url + ("&" if "?" in url else "?") + f"click_id={lead}"


_PB_LAST: list = []
_PB_WARN = [0.0]


async def pb(request: Request):
    """Pocket Option affiliate postback (direct, or forwarded by the ARTUR channel bot).
    /pb/<POSTBACK_SECRET>?click={click_id}&event=reg|ftd&amount={sumdep}&trader={trader_id}"""
    keys = {k for k in (config.POSTBACK_SECRET, os.getenv("POSTBACK_SECRET2", ""), os.getenv("POSTBACK_SECRET3", "")) if k}
    if not keys or request.path_params.get("secret") not in keys:
        return PlainTextResponse("forbidden", status_code=403)
    q = dict(request.query_params)
    if request.method == "POST":
        try:
            q.update(dict(await request.form()))
        except Exception:  # noqa: BLE001
            pass
    # the lead id may come back in click_id or in sub_id1 (both are put into the personal link) — take the valid one
    cands = [str(q.get(k) or "") for k in ("click", "click_id", "sid", "sub_id1", "sub_id")]
    click = next((c for c in cands if c.startswith(config.CLICK_PREFIX) and c[len(config.CLICK_PREFIX):].isdigit()), "")
    trader = str(q.get("trader") or q.get("trader_id") or "")
    ev = str(q.get("event") or q.get("type") or "")
    try:
        amt = float(str(q.get("amount") or q.get("sumdep") or q.get("sum") or q.get("deposit") or 0).replace(",", "."))
    except ValueError:
        amt = 0.0
    raw_q = {k: str(v)[:60] for k, v in q.items()}
    _PB_LAST.insert(0, (time.time(), raw_q))
    del _PB_LAST[20:]
    if "{" in trader or all("{" in c or not c for c in cands):
        # the partner program sent its macro NAMES instead of values ({trader_id}, {click_id}) → the postback URL in the
        # Pocket Partners cabinet uses macros it does not know (or it was a test send). Nobody can be matched from it.
        logging.getLogger("postback").warning("POSTBACK with unfilled macros: %s", raw_q)
        if time.time() - _PB_WARN[0] > 6 * 3600:
            _PB_WARN[0] = time.time()
            try:
                hub.alert("pb_macros")
            except Exception:  # noqa: BLE001
                pass
        if "{" in trader:
            return PlainTextResponse("ignored: macros not filled")
    journal.pb_record(trader, click or cands[0], ev, amt)
    if not click:                       # registered without the bot link → match by the Trader ID the user gave us
        tu = journal.uid_by_trader(trader)
        if tu:
            click = f"{config.CLICK_PREFIX}{tu}"
    logging.getLogger("postback").info("POSTBACK event=%s click=%s trader=%s amount=%s", q.get("event"), click or cands, q.get("trader"), q.get("amount"))
    if not click:
        return PlainTextResponse("ignored")            # a lead of another funnel (e.g. the ARTUR channel)
    uid = int(click[len(config.CLICK_PREFIX):])
    try:
        amount = float(str(q.get("amount") or q.get("sumdep") or q.get("sum") or q.get("deposit") or 0).replace(",", "."))
    except ValueError:
        amount = 0.0
    changed = journal.postback(uid, str(q.get("event") or q.get("type") or ""), str(q.get("trader") or q.get("trader_id") or ""), amount)
    if changed:
        try:
            hub.reqs.put_nowait({"postback": changed, "uid": uid, "amount": amount})
        except Exception:  # noqa: BLE001
            pass
    return PlainTextResponse("ok")


def _can(uid: int) -> bool:
    return bool(_gate(uid))


def _gate(uid: int) -> str:
    """full = access · trial = free signals left (before registration) · '' = locked."""
    if journal.user(uid).get("access") or config.ACCESS_OPEN or uid in _admins():
        return "full"
    return "trial" if journal.trial_left(uid) > 0 else ""


def _denied():
    if int(getattr(config, "TRIAL_SIGNALS", 0) or 0) > 0:
        return JSONResponse({"error": "trial_over", "trial_left": 0, "trial_total": config.TRIAL_SIGNALS}, status_code=403)
    return JSONResponse({"error": "no_access"}, status_code=403)


def _trial_spend(uid: int, gate: str) -> dict:
    """A free signal was issued → count it; the last one → the bot sends the registration card."""
    if gate != "trial":
        return {}
    left = journal.trial_use(uid)
    if left <= 0:
        try:
            hub.reqs.put_nowait({"trial_over": uid})
        except Exception:  # noqa: BLE001
            pass
    return {"trial_left": left, "trial_total": config.TRIAL_SIGNALS}


def _admins() -> set:
    ids = set(config.ADMIN_IDS)
    if config.COOKIE_ADMIN_ID:
        ids.add(config.COOKIE_ADMIN_ID)
    return ids


@need_user
async def auto_state(request: Request):
    """ARTUR AUTO: the shared live window of a track (normal | fast)."""
    from app import autofeed as A
    uid = int(request.state.user["id"])
    if not _can(uid):
        return _denied()
    track = request.query_params.get("track") or "normal"
    st = A.user_state(uid, track)
    w = st.get("window")
    if w and hub.provider:
        try:
            await hub.provider.want(w["inst"])
        except Exception:  # noqa: BLE001
            pass
    last = hub.last(w["inst"]) if w else None
    mine = None
    if w:
        t = A.my_trade(uid, w["id"])
        if t:
            mine = {**t, **{k: v for k, v in A._pnl(w, t["amount"], t["joined"], t.get("exp")).items() if k != "played"}}
    st.update(price=last[0] if last else None, mine=mine,
              recent=A.recent(12, track) if request.query_params.get("full") else None,
              stats=A.stats(24, track, _exp(request)), push=bool(journal.user(uid).get("push_on")) and (journal.user(uid).get("push_track") or "normal") == track)
    return JSONResponse(st)


@need_user
async def focus(request: Request):
    """What the user has open in the app — «Режим одного телефона» follows exactly this."""
    b = await request.json()
    ctx = b.get("ctx") if b.get("ctx") in ("manual", "normal", "fast") else "manual"
    kw = {"push_track": ctx}
    try:
        if ctx != "manual" and int(b.get("exp") or 0) > 0:
            kw["push_exp"] = int(b["exp"])
    except (TypeError, ValueError):
        pass
    journal.upsert_user(int(request.state.user["id"]), **kw)
    return JSONResponse({"ok": True})


@need_user
async def phone_mode(request: Request):
    """«Режим одного телефона» on/off."""
    b = await request.json()
    on = 1 if b.get("on") else 0
    uid = int(request.state.user["id"])
    was = bool(journal.user(uid).get("phone"))
    journal.upsert_user(uid, phone=on)
    if on and not was:
        try:
            hub.reqs.put_nowait({"phone_on": uid})
        except Exception:  # noqa: BLE001
            pass
    return JSONResponse({"ok": True, "phone": bool(on)})


@need_user
async def auto_push(request: Request):
    b = await request.json()
    kw = {"push_on": 1 if b.get("on") else 0}
    if b.get("track") in ("normal", "fast"):
        kw["push_track"] = b["track"]
    if b.get("exp"):
        kw["push_exp"] = int(b["exp"])
    if b.get("amount"):
        kw["push_amount"] = max(1.0, min(10000.0, float(b["amount"])))
    journal.upsert_user(int(request.state.user["id"]), **kw)
    return JSONResponse({"ok": True})


@need_user
async def metro(request: Request):
    b = await request.json()
    journal.upsert_user(int(request.state.user["id"]), metro=1 if b.get("on") else 0)
    return JSONResponse({"ok": True})


@need_user
async def auto_next(request: Request):
    from app import autofeed as A
    if not _can(int(request.state.user["id"])):
        return _denied()
    b = await request.json()
    track = b.get("track") if b.get("track") in A.FEEDS else "normal"
    return JSONResponse({"ok": A.user_next(int(request.state.user["id"]), track)})


@need_user
async def auto_join(request: Request):
    from app import autofeed as A
    uid = int(request.state.user["id"])
    gate = _gate(uid)
    if not gate:
        return _denied()
    b = await request.json()
    if b.get("leave"):
        A.leave(uid, int(b.get("wid") or 0))
        return JSONResponse({"ok": True})
    amount = max(1.0, min(10000.0, float(b.get("amount") or 10)))
    wid = int(b.get("wid") or 0)
    had = A.my_trade(uid, wid) if gate == "trial" else None
    r = A.join(uid, wid, amount, int(b.get("exp") or 0) or None)
    if isinstance(r, dict) and r.get("ok") and not had:
        r = {**r, **_trial_spend(uid, gate)}
    return JSONResponse(r)


@need_user
async def auto_history(request: Request):
    from app import autofeed as A
    uid = int(request.state.user["id"])
    q = request.query_params
    if q.get("mine"):
        return JSONResponse({"items": A.my_history(uid)})
    track = q.get("track") or None
    return JSONResponse({"items": A.recent(int(q.get("n") or 40), track), "stats": A.stats(24 * 7, track, _exp(request))})


def _exp(request) -> Optional[int]:
    try:
        return int(request.query_params.get("exp") or 0) or None
    except ValueError:
        return None


@need_user
async def auto_window(request: Request):
    """«Разбор окна»: every entry with price path, result per expiry and an explanation."""
    from app import autofeed as A
    uid = int(request.state.user["id"])
    w = A.window_detail(int(request.query_params.get("id") or 0))
    if not w:
        return JSONResponse({"error": "not found"}, status_code=404)
    t = A.my_trade(uid, w["id"])
    if t:
        w["mine"] = {**t, **{k: v for k, v in A._pnl(w, t["amount"], t["joined"], t.get("exp")).items() if k != "played"}}
    return JSONResponse(w)


@need_user
async def signal_next(request: Request):
    """ARTUR system: the previous entry of a window was not a win → next entry, same pair/expiry."""
    uid = int(request.state.user["id"])
    b = await request.json()
    r = next_entry(uid, int(b.get("sid") or 0), int(b.get("max") or os.getenv("MAX_ATTEMPTS") or 3))
    return JSONResponse(r[0], status_code=r[1])


def next_entry(uid: int, sid: int, n: int):
    """Shared by the app and «Режим одного телефона». Idempotent: the same next entry is never created twice."""
    prev = journal.get(sid)
    if not prev or prev["uid"] != uid:
        return {"error": "not found"}, 404
    att = int(prev.get("attempt") or 1)
    if prev["result"] == "WIN" or att >= n:
        return {"done": True}, 200
    wid0 = prev.get("win_id") or prev["id"]
    ex = journal._db.execute("SELECT id FROM signals WHERE win_id=? AND attempt=?", (wid0, att + 1)).fetchone()
    if ex:
        return {"signal": journal.get(ex["id"]), "server_time": time.time(), "attempt": att + 1, "max": n,
                "flipped": bool((journal.get(ex["id"]).get("factors") or {}).get("flipped"))}, 200
    inst = hub.instruments.get(prev["inst"])
    if not inst or not inst.active:
        return {"done": True, "reason": "пара закрыта"}, 200
    # think before the next entry: if ARTUR now leans the other way, the next entry turns with the market
    flip = None
    try:
        from app import autofeed as _A
        if _A.FLIP_ON_REVERSE and _A.market_against(inst.id, prev["direction"], prev.get("entry_price"), prev["result"]):
            flip = "SELL" if prev["direction"] == "BUY" else "BUY"       # the chart went the other way → with it
    except Exception:  # noqa: BLE001
        pass
    try:
        if flip:
            raise StopIteration
        tfs =config.TIMEFRAMES.get(prev.get("tf") or "1m", 60)
        cs = hub.candles(inst.id, tfs, 200)
        if len(cs) >= 40:
            chk = AR.analyze(inst.id, cs, inst.payout, config.PAYOUT_MIN, tfs)
            v = chk.get("votes") or 0
            if (prev["direction"] == "BUY" and v < 0) or (prev["direction"] == "SELL" and v > 0):
                if os.getenv("FLIP_ON_REVERSE", "1").lower() in ("1", "true", "yes", "on"):
                    flip = "SELL" if prev["direction"] == "BUY" else "BUY"      # go WITH the market now
                else:
                    return {"done": True, "reason": "Анализ ARTUR сменил направление — окно остановлено, "
                                                    "чтобы не входить против рынка."}, 200
    except Exception:  # noqa: BLE001
        pass
    dec = prev.get("factors") or {}
    from app import autofeed as A
    wid0 = prev.get("win_id") or prev["id"]
    chain = journal._db.execute("SELECT amount, result FROM signals WHERE id=? OR win_id=? ORDER BY id", (wid0, wid0)).fetchall()
    base = float(chain[0]["amount"] or prev["amount"]) if chain else float(prev["amount"])
    amount = A.ladder(inst.payout, base, [c["result"] for c in chain])["next"]
    if flip:
        dec = {**dec, "flipped": True}
    sig = journal.create(uid, inst, prev["engine"], prev["strategy"], flip or prev["direction"], prev["tf"], prev["expiry"],
                         amount, dec, delay=_entry_delay(uid))
    journal.set_window(sig["id"], prev.get("win_id") or prev["id"], att + 1, "artur")
    _metro(journal.get(sig["id"]))
    return {"signal": journal.get(sig["id"]), "server_time": time.time(), "attempt": att + 1, "max": n,
            "flipped": bool(flip)}, 200



def _entry_delay(uid: int):
    """«Режим одного телефона»: more time to switch to the broker app before the entry."""
    try:
        if journal.user(uid).get("phone"):
            return float(os.getenv("PHONE_ENTRY_DELAY", "20"))
    except Exception:  # noqa: BLE001
        pass
    return None


@need_user
async def profile_stats(request: Request):
    """Pocket-style trading profile: the user's own trades, or ARTUR AI (the bot's auto windows)."""
    from app import autofeed as A
    uid = int(request.state.user["id"])
    who = request.query_params.get("who") or "me"
    trades = []
    if who == "ai":
        stake = 10.0
        for w in reversed(A.recent(400)):
            rs = [A.res_of(w, a, None) for a in w["attempts"]]
            rs = [r for r in rs if r]
            if not rs or all(r == "ERROR" for r in rs):
                continue
            lad = A.ladder(w["payout"], stake, rs)          # one window = one trade (overlap included)
            trades.append({"ts": w["attempts"][0]["entry_at"], "inst": w["inst"], "name": w["name"], "amount": lad["staked"], "exp": (w.get("expiries") or [None])[-1],
                           "pnl": lad["pnl"], "result": "WIN" if lad["pnl"] > 0 else "LOSS" if lad["pnl"] < 0 else "DRAW"})
    else:
        grp: dict = {}
        for r in reversed(journal.history(uid, 500)):      # ARTUR windows (several entries) = one trade
            k = r.get("win_id") or r["id"]
            g = grp.get(k)
            if not g:
                grp[k] = g = {"ts": r["created"], "inst": r["inst"], "name": r["name"], "amount": 0.0, "pnl": 0.0, "res": [], "exp": r.get("expiry")}
            g["amount"] += r["amount"] or 0
            g["pnl"] += (r["my_pnl"] if r.get("my_result") else r["pnl"]) or 0.0
            g["res"].append(r.get("my_result") or r["result"])
        for g in grp.values():
            done = [x for x in g["res"] if x in ("WIN", "LOSS", "DRAW")]
            if not done:
                continue
            trades.append({"ts": g["ts"], "inst": g["inst"], "name": g["name"], "amount": round(g["amount"], 2), "exp": g.get("exp"),
                           "pnl": round(g["pnl"], 2), "result": "WIN" if g["pnl"] > 0 else "LOSS" if g["pnl"] < 0 else "DRAW"})
        for w in A.my_history(uid, 300):
            p = A._pnl(w, w["amount"], w["joined"], w.get("my_exp"))
            if p["played"]:
                trades.append({"ts": p["played"][0]["entry_at"], "inst": w["inst"], "name": w["name"], "amount": p["staked"], "exp": p.get("exp"),
                               "pnl": p["pnl"], "result": "WIN" if p["pnl"] > 0 else "LOSS" if p["pnl"] < 0 else "DRAW"})
        trades.sort(key=lambda t: t["ts"])
    d = journal.dashboard(trades, os.getenv("TIMEZONE") or "Europe/Prague")
    d["who"] = who
    u = journal.user(uid) or {}
    d["trader_id"] = u.get("po_trader") or u.get("trader_id")
    if who == "ai":
        d["note"] = "ARTUR AI: каждое авто-окно — одна сделка (с перекрытием после минуса): плюс или минус."
    return JSONResponse(d)


@need_user
async def insight_api(request: Request):
    """ARTUR TERMINAL: full indicator picture of one pair — tiles, gauge, M1/M5/M15, patterns, levels, score."""
    from app import terminal as TM
    q = request.query_params
    inst = hub.instruments.get(q.get("inst", ""))
    if not inst:
        return JSONResponse({"error": "unknown"}, status_code=400)
    tf = config.TIMEFRAMES.get(q.get("tf") or "1m", 60)
    if hub.provider:
        await hub.provider.want(inst.id)
    return JSONResponse(await asyncio.to_thread(TM.insight, inst, tf))


@need_user
async def market_api(request: Request):
    """PO MARKET: every Pocket Option pair of the market with price, change, sparkline, ARTUR reading."""
    from app import terminal as TM
    return JSONResponse(await asyncio.to_thread(TM.market_list, request.query_params.get("market") or "OTC"))


@need_user
async def radar_api(request: Request):
    """РАДАР ARTUR: which pairs to trade / be careful with / avoid right now, with the reasons."""
    from app import radar as R
    return JSONResponse(await asyncio.to_thread(R.radar, request.query_params.get("market") or "OTC"))


async def regime(request: Request):
    """Market volatility state for OTC/FOREX — used to warn the user before trading."""
    return JSONResponse(C.market_regime(request.query_params.get("market")))


@need_user
async def core(request: Request):
    """ARTUR CORE: 10 modules + ARTUR FUSION for one pair (live data, «н/д» when unknown)."""
    q = request.query_params
    inst = hub.instruments.get(q.get("inst", ""))
    if not inst:
        return JSONResponse({"error": "unknown"}, status_code=400)
    tf_name = q.get("tf") if q.get("tf") in config.TIMEFRAMES else "1m"
    exp_name = q.get("expiry") if q.get("expiry") in config.EXPIRIES else "1m"
    if hub.provider:
        await hub.provider.want(inst.id)
        tw = C.twin(inst)
        if tw:
            await hub.provider.want(tw.id)
    return JSONResponse(C.analyze(inst, tf_name, exp_name, int(request.state.user["id"])))


async def health(_):
    return PlainTextResponse("ok")


from app import poster as _poster   # noqa: E402
app = Starlette(routes=[
    Route("/", health), Route("/app", page),
    Route("/p/{pid}.jpg", _poster.image), Route("/p/{pid}", _poster.page),
    Route("/api/me", me), Route("/api/instruments", instruments), Route("/api/candles", candles),
    Route("/api/trends", trends), Route("/api/stream", stream), Route("/api/pulse", pulse), Route("/api/regime", regime), Route("/api/radar", radar_api), Route("/api/insight", insight_api), Route("/api/market", market_api), Route("/api/core", core), Route("/api/auto", auto_state), Route("/api/auto/push", auto_push, methods=["POST"]), Route("/api/phone", phone_mode, methods=["POST"]), Route("/api/focus", focus, methods=["POST"]), Route("/api/auto/join", auto_join, methods=["POST"]), Route("/api/auto/history", auto_history), Route("/api/auto/window", auto_window), Route("/api/auto/next", auto_next, methods=["POST"]), Route("/api/metro", metro, methods=["POST"]), Route("/api/signal/{sid:int}/verify", signal_verify, methods=["POST"]), Route("/api/signal/active", signal_active), Route("/api/signal/{sid:int}/recheck", signal_recheck, methods=["POST"]), Route("/api/signal/next", signal_next, methods=["POST"]), Route("/api/profile/stats", profile_stats), Route("/pb/{secret}", pb, methods=["GET", "POST"]), Route("/api/ref", ref), Route("/api/autosignal", autosignal, methods=["POST"]),
    Route("/api/analyze", analyze, methods=["POST"]), Route("/api/signal/{sid:int}", signal),
    Route("/api/history", history), Route("/api/register", register, methods=["POST"]),
    Route("/api/session/start", session_start, methods=["POST"]), Route("/api/session/next", session_next, methods=["POST"]),
    Route("/api/session/{sid:int}", session_view), Route("/api/sessions", sessions), Route("/api/lang", set_lang, methods=["POST"]),
    Mount("/static", StaticFiles(directory=str(WEB)), name="static"),
])
