"""Telegram bot on the plain Bot API (httpx long polling).

/start → language → welcome + «Открыть ARTUR» (Web App) + disclaimer.
Onboarding: registration link → user sends trader ID → admin approves/rejects.
Admin: /admin (requests + counts).
"""
from __future__ import annotations

import asyncio
import json
import re
import os
import html
import logging
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx
from urllib.parse import quote

from app import config, journal
from app.market.hub import hub

CARD_V = "7"          # bump when the card pictures change (Telegram caches files by URL)

log = logging.getLogger("bot")
API = f"https://api.telegram.org/bot{config.BOT_TOKEN}"

T = {
    "ru": {"choose": "🌐 Выбери язык", "hello": "👋 <b>Привет, {n}!</b>\n\n<b>ARTUR TRADE</b> — аналитика OTC и Forex под брокера Pocket Option: живые котировки, разбор сигнала по факторам и честный журнал всех сигналов — с плюсами и минусами.",
           "open": "⚡️ Открыть ARTUR", "reg": "📝 Регистрация на Pocket Option", "id": "🆔 Отправить ID трейдера",
           "steps": "\n\n<b>Доступ:</b>\n1. Зарегистрируйся по кнопке (новый аккаунт)\n2. Пришли сюда свой ID трейдера\n3. После проверки откроется доступ",
           "disc": "\n\n<i>Сигналы — аналитика, а не гарантия результата. Торговля связана с риском потери средств. 18+.</i>",
           "askid": "Пришли свой ID трейдера Pocket Option одним сообщением (только цифры).",
           "sent": "✅ ID отправлен на проверку. Обычно это занимает немного времени — бот напишет, когда доступ откроется.",
           "ok": "🎉 Доступ открыт! Жми «Открыть ARTUR».", "no": "❌ ID не подтверждён. Проверь, что аккаунт создан по нашей ссылке, и пришли ID ещё раз."},
    "ua": {"choose": "🌐 Обери мову", "hello": "👋 <b>Привіт, {n}!</b>\n\n<b>ARTUR TRADE</b> — аналітика OTC та Forex під брокера Pocket Option: живі котирування, розбір сигналу за факторами та чесний журнал усіх сигналів — з плюсами й мінусами.",
           "open": "⚡️ Відкрити ARTUR", "reg": "📝 Реєстрація на Pocket Option", "id": "🆔 Надіслати ID трейдера",
           "steps": "\n\n<b>Доступ:</b>\n1. Зареєструйся за кнопкою (новий акаунт)\n2. Надішли сюди свій ID трейдера\n3. Після перевірки відкриється доступ",
           "disc": "\n\n<i>Сигнали — аналітика, а не гарантія результату. Торгівля пов'язана з ризиком втрати коштів. 18+.</i>",
           "askid": "Надішли свій ID трейдера Pocket Option одним повідомленням (лише цифри).",
           "sent": "✅ ID надіслано на перевірку — бот напише, коли доступ відкриється.",
           "ok": "🎉 Доступ відкрито! Тисни «Відкрити ARTUR».", "no": "❌ ID не підтверджено. Перевір, що акаунт створено за нашим посиланням, і надішли ID ще раз."},
    "en": {"choose": "🌐 Choose language", "hello": "👋 <b>Hi, {n}!</b>\n\n<b>ARTUR TRADE</b> — OTC & Forex analytics for Pocket Option: live quotes, factor-by-factor signal breakdown and an honest journal of every signal — wins and losses.",
           "open": "⚡️ Open ARTUR", "reg": "📝 Sign up at Pocket Option", "id": "🆔 Send trader ID",
           "steps": "\n\n<b>Access:</b>\n1. Sign up via the button (new account)\n2. Send your trader ID here\n3. Access opens after verification",
           "disc": "\n\n<i>Signals are analytics, not a guarantee. Trading involves risk of losing money. 18+.</i>",
           "askid": "Send your Pocket Option trader ID in one message (digits only).",
           "sent": "✅ ID sent for verification — the bot will message you when access opens.",
           "ok": "🎉 Access granted! Tap «Open ARTUR».", "no": "❌ ID not confirmed. Make sure the account was created via our link and send the ID again."},
}


# ---- funnel captions & buttons (cards are images in web/img/f_*.png) ----
FN = {
 "ru": {"cap_welcome": "<b>Приветствуем в торговой системе ARTUR TRADE.</b>\n\nЧтобы получить доступ к боту — выполни условия ниже.",
        "cap_step1": "<b>Регистрация — и доступ открыт</b>\n\n1. Создай <b>новый аккаунт</b> по нашей ссылке\n2. Нажми «Проверить ID» и отправь свой Trader ID\n\n✅ Депозит для доступа <b>не нужен</b> — доступ открывается сразу после регистрации.\n⚠️ Нужен именно новый аккаунт по нашей ссылке — иначе бот его не увидит.",
        "cap_pending": "<b>ID на проверке</b>\n\nТвой ID отправлен на проверку. Бот напишет, как только доступ откроется.",
        "cap_access": "<b>🎉 Доступ открыт!</b>\n\nЖми «Открыть ARTUR» и заходи в приложение.",
        "cap_reject": "<b>ID не подтверждён</b>\n\nПроверь, что аккаунт создан по нашей ссылке, и отправь ID ещё раз.",
        "cap_hello": "<b>Привет, трейдер!</b>\nРады видеть в <b>ARTUR TRADE BOT</b>.\n\nЕсли ты зашёл сюда — ты уже на правильном пути. Живые котировки OTC и Forex, разбор сигнала по факторам и честный журнал.\n\nЖми <b>ARTUR TRADE</b>{trial}.",
        "b_app": "⚡️ ARTUR TRADE",
        "b_start": "➡️ Начать", "b_reg": "📝 Регистрация по ссылке", "b_check": "🆔 Проверить ID",
        "b_open": "⚡️ Открыть ARTUR", "b_retry": "🔄 Отправить ID заново",
        "ask_id": "Пришли свой Trader ID одним сообщением (только цифры).",
        "chk": ["Принял ID…", "Сверяю с партнёркой…", "Отправляю на проверку…", "Готово ✅"]},
 "ua": {"cap_welcome": "<b>Вітаємо в торговій системі ARTUR TRADE.</b>\n\nЩоб отримати доступ до бота — виконай умови нижче.",
        "cap_step1": "<b>Реєстрація — і доступ відкрито</b>\n\n1. Створи <b>новий акаунт</b> за нашим посиланням\n2. Натисни «Перевірити ID» і надішли свій Trader ID\n\n✅ Депозит для доступу <b>не потрібен</b> — доступ відкривається одразу після реєстрації.\n⚠️ Потрібен саме новий акаунт за нашим посиланням — інакше бот його не побачить.",
        "cap_pending": "<b>ID на перевірці</b>\n\nТвій ID надіслано на перевірку. Бот напише, щойно доступ відкриється.",
        "cap_access": "<b>🎉 Доступ відкрито!</b>\n\nТисни «Відкрити ARTUR» і заходь у застосунок.",
        "cap_reject": "<b>ID не підтверджено</b>\n\nПеревір, що акаунт створено за нашим посиланням, і надішли ID ще раз.",
        "cap_hello": "<b>Привіт, трейдере!</b>\nРаді бачити в <b>ARTUR TRADE BOT</b>.\n\nЯкщо ти зайшов сюди — ти вже на правильному шляху. Живі котирування OTC та Forex, розбір сигналу за факторами та чесний журнал.\n\nТисни <b>ARTUR TRADE</b>{trial}.",
        "b_app": "⚡️ ARTUR TRADE",
        "b_start": "➡️ Почати", "b_reg": "📝 Реєстрація за посиланням", "b_check": "🆔 Перевірити ID",
        "b_open": "⚡️ Відкрити ARTUR", "b_retry": "🔄 Надіслати ID ще раз",
        "ask_id": "Надішли свій Trader ID одним повідомленням (лише цифри).",
        "chk": ["Прийняв ID…", "Звіряю з партнеркою…", "Надсилаю на перевірку…", "Готово ✅"]},
 "en": {"cap_welcome": "<b>Welcome to the ARTUR TRADE system.</b>\n\nTo get access to the bot — complete the steps below.",
        "cap_step1": "<b>Sign up — and access is open</b>\n\n1. Create a <b>new account</b> via our link\n2. Tap «Verify ID» and send your Trader ID\n\n✅ <b>No deposit needed</b> for access — it opens right after registration.\n⚠️ It must be a new account via our link — otherwise the bot can't see it.",
        "cap_pending": "<b>ID under review</b>\n\nYour ID was sent for verification. The bot will message you once access opens.",
        "cap_access": "<b>🎉 Access granted!</b>\n\nTap «Open ARTUR» and enter the app.",
        "cap_reject": "<b>ID not confirmed</b>\n\nMake sure the account was created via our link and send the ID again.",
        "cap_hello": "<b>Hi, trader!</b>\nGlad to see you in <b>ARTUR TRADE BOT</b>.\n\nIf you're here — you're already on the right track. Live OTC & Forex quotes, factor-by-factor signal breakdown and an honest journal.\n\nTap <b>ARTUR TRADE</b>{trial}.",
        "b_app": "⚡️ ARTUR TRADE",
        "b_start": "➡️ Start", "b_reg": "📝 Sign up via link", "b_check": "🆔 Verify ID",
        "b_open": "⚡️ Open ARTUR", "b_retry": "🔄 Send ID again",
        "ask_id": "Send your Trader ID in one message (digits only).",
        "chk": ["ID received…", "Checking with the partner…", "Sending for review…", "Done ✅"]},
}


def _base_url() -> str:
    u = config.WEBAPP_URL or ""
    return u[:-4] if u.endswith("/app") else u.rstrip("/")


class Bot:
    def __init__(self) -> None:
        self.c = httpx.AsyncClient(timeout=40)
        self.waiting_id: set[int] = set()

    def fn(self, uid: int, key: str):
        return FN.get(journal.user(uid).get("lang") or "ru", FN["ru"])[key]

    def card_url(self, name: str) -> str:
        return f"{_base_url()}/static/img/{name}.jpg?v={CARD_V}"

    def hello_kb(self, uid: int) -> list:
        lang = journal.user(uid).get("lang") or "ru"
        a, f = {"ua": ("📱 ARTUR TRADE · угоди 1 хв", "⚡ POCKET FAST · угоди 3–5 сек"),
                "en": ("📱 ARTUR TRADE · 1 min trades", "⚡ POCKET FAST · 3–5 sec trades")}.get(lang, ("📱 ARTUR TRADE · сделки 1 мин", "⚡ POCKET FAST · сделки 3–5 сек"))
        rows = [[{"text": a, "web_app": {"url": config.WEBAPP_URL}}], [{"text": f, "callback_data": "fast"}]]
        rows.append([{"text": "👥 Пригласи друга · награда в $", "callback_data": "partner"}])
        rows.append([{"text": "🇷🇺 RU", "callback_data": "lang:ru"},
                     {"text": "🇺🇦 UA", "callback_data": "lang:ua"},
                     {"text": "🇬🇧 EN", "callback_data": "lang:en"}])
        return rows

    async def card(self, uid: int, name: str, caption: str, buttons=None) -> None:
        p = {"chat_id": uid, "photo": self.card_url(name), "caption": caption, "parse_mode": "HTML"}
        if buttons is not None:
            p["reply_markup"] = {"inline_keyboard": buttons}
        r = None
        if os.path.exists(os.path.join(os.path.dirname(__file__), "..", "web", "img", f"{name}.mp4")):
            # animated card: the picture with a soft light sweep (plays silently, looped, like a premium banner)
            a = dict(p)
            a.pop("photo")
            a["animation"] = f"{_base_url()}/static/img/{name}.mp4?v={CARD_V}"
            r = await self.call("sendAnimation", **a)
        if not r:
            r = await self.call("sendPhoto", **p)
        if not r:   # fallback if the image URL is not reachable yet
            p.pop("photo", None)
            r = await self.call("sendMessage", chat_id=uid, text=caption, parse_mode="HTML",
                                reply_markup=p.get("reply_markup"))
        return r

    async def loader(self, uid: int, title: str, steps: list) -> None:
        """Live loading animation in the chat (a self-editing progress bar) between funnel steps."""
        m = await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                            text=f"⚡️ <b>{title}</b>\n<code>▱▱▱▱▱▱▱▱▱▱  0%</code>")
        if not m:
            return
        n = len(steps)
        for i, txt in enumerate(steps, 1):
            await asyncio.sleep(0.4)
            pct = round(i / n * 100)
            bar = "▰" * (pct // 10) + "▱" * (10 - pct // 10)
            await self.call("editMessageText", chat_id=uid, message_id=m["message_id"], parse_mode="HTML",
                            text=f"⚡️ <b>{title}</b>\n<code>{bar}  {pct}%</code>\n{html.escape(txt)}")
        await asyncio.sleep(0.3)
        await self.call("deleteMessage", chat_id=uid, message_id=m["message_id"])

    async def call(self, method: str, **params):
        try:
            r = await self.c.post(f"{API}/{method}", json=params)
            d = r.json()
            if not d.get("ok"):
                log.warning("%s: %s", method, d)
            return d.get("result")
        except Exception as e:  # noqa: BLE001
            log.warning("%s failed: %s", method, e)

    # ---------------------------------------------------- private channel access --
    PRIV_T = {"ru": ("⚡ Вступить в POCKET FAST", "⚡ <b>POCKET FAST</b> — приватный канал\n\nЖми кнопку и отправь заявку — бот одобрит её автоматически.",
                     "⚡ <b>POCKET FAST</b> — приватный канал\n\nВход открывается после регистрации по нашей ссылке. Пройди 2 шага — и заявка одобрится сама."),
              "ua": ("⚡ Вступити в POCKET FAST", "⚡ <b>POCKET FAST</b> — приватний канал\n\nТисни кнопку й надішли заявку — бот схвалить її автоматично.",
                     "⚡ <b>POCKET FAST</b> — приватний канал\n\nВхід відкривається після реєстрації за нашим посиланням. Пройди 2 кроки — і заявка схвалиться сама."),
              "en": ("⚡ Join POCKET FAST", "⚡ <b>POCKET FAST</b> private channel\n\nTap the button and send a join request — the bot approves it automatically.",
                     "⚡ <b>POCKET FAST</b> private channel\n\nAccess opens after registration via our link. Complete 2 steps and your request is approved automatically.")}

    def _priv(self) -> str:
        return (os.getenv("PRIVATE_CHAT_ID") or os.getenv("ARTFS_CHAT_ID") or "").strip()

    def _privt(self, uid: int) -> tuple:
        return self.PRIV_T.get(journal.user(uid).get("lang") or "ru", self.PRIV_T["ru"])

    async def priv_rows(self, uid: int) -> list:
        """Personal join-request link to the private channel (approved only for users with access)."""
        ch = self._priv()
        if not ch:
            return []
        r = await self.call("createChatInviteLink", chat_id=ch, name=f"artur u{uid}"[:32], creates_join_request=True)
        link = (r or {}).get("invite_link")
        return [[{"text": self._privt(uid)[0], "url": link}]] if link else []

    async def priv_send(self, uid: int) -> None:
        rows = await self.priv_rows(uid)
        if rows:
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self._privt(uid)[1],
                            reply_markup={"inline_keyboard": rows})

    async def priv_kick(self, uid: int) -> None:
        """Access revoked → remove from the private channel (unban right away, so a new approval lets them back in)."""
        ch = self._priv()
        if ch and uid not in self._admins():
            await self.call("banChatMember", chat_id=ch, user_id=uid, until_date=int(time.time()) + 60)
            await self.call("unbanChatMember", chat_id=ch, user_id=uid, only_if_banned=True)

    async def on_join(self, r: dict) -> None:
        """Join request to the private channel: approve verified users, decline others and send them the funnel."""
        if str(r.get("chat", {}).get("id")) != self._priv():
            return
        f = r.get("from") or {}
        uid = int(f.get("id", 0))
        journal.upsert_user(uid, username=f.get("username", ""), name=f.get("first_name", ""))
        ok = bool(journal.user(uid).get("access")) or uid in self._admins()
        await self.call("approveChatJoinRequest" if ok else "declineChatJoinRequest", chat_id=r["chat"]["id"], user_id=uid)
        log.info("private channel join request %s → %s", uid, "approved" if ok else "declined")
        if not ok:
            await self.call("sendMessage", chat_id=r.get("user_chat_id") or uid, parse_mode="HTML", text=self._privt(uid)[2])
            await self.step1(uid)

    def t(self, uid: int, key: str) -> str:
        return T.get(journal.user(uid).get("lang") or "ru", T["ru"])[key]

    PROMO = {"ru": "\n\n🎁 <b>Промокоды на бонус к депозиту</b> (по желанию):\n"
                   "• <code>WELCOME50</code> — +50% к депозиту, мин. депозит $10\n"
                   "• <code>50START</code> — +50% к депозиту от $50\n"
                   "<i>Промокод вводится при пополнении. Условия бонуса — у брокера; бонус не гарантирует прибыль.</i>",
             "ua": "\n\n🎁 <b>Промокоди на бонус до депозиту</b> (за бажанням):\n"
                   "• <code>WELCOME50</code> — +50% до депозиту, мін. депозит $10\n"
                   "• <code>50START</code> — +50% до депозиту від $50\n"
                   "<i>Промокод вводиться під час поповнення. Умови бонусу — у брокера; бонус не гарантує прибутку.</i>",
             "en": "\n\n🎁 <b>Deposit bonus promo codes</b> (optional):\n"
                   "• <code>WELCOME50</code> — +50% to the deposit, min. deposit $10\n"
                   "• <code>50START</code> — +50% to a deposit from $50\n"
                   "<i>Enter the code when you top up. Bonus terms are set by the broker; a bonus does not guarantee profit.</i>"}
    TRIAL = {"ru": (" — первые <b>{n} сигнала бесплатно</b>, без регистрации", " — внутри пройдёшь быстрый вход и получишь доступ"),
             "ua": (" — перші <b>{n} сигнали безкоштовно</b>, без реєстрації", " — всередині пройдеш швидкий вхід і отримаєш доступ"),
             "en": (" — your first <b>{n} signals are free</b>, no sign-up", " — inside you'll do a quick entry and get access")}
    TRIAL_OVER = {"ru": "⏳ <b>Бесплатные сигналы закончились ({n} из {n})</b>\n\nХочешь дальше — зарегистрируйся по нашей ссылке и пришли Trader ID. <b>Депозит не нужен</b> — доступ откроется сразу.\n\n",
                  "ua": "⏳ <b>Безкоштовні сигнали закінчились ({n} з {n})</b>\n\nХочеш далі — зареєструйся за нашим посиланням і надішли Trader ID. <b>Депозит не потрібен</b> — доступ відкриється одразу.\n\n",
                  "en": "⏳ <b>Free signals are used up ({n} of {n})</b>\n\nWant more — sign up via our link and send your Trader ID. <b>No deposit needed</b> — access opens right away.\n\n"}

    def _lang(self, uid: int) -> str:
        lg = (journal.user(uid) or {}).get("lang") or "ru"
        return lg if lg in self.PROMO else "ru"

    def promo(self, uid: int) -> str:
        return self.PROMO[self._lang(uid)] if os.getenv("PROMO_CODES", "true").lower() in ("1", "true", "yes", "on") else ""

    def hello_cap(self, uid: int) -> str:
        n = int(getattr(config, "TRIAL_SIGNALS", 0) or 0)
        u = journal.user(uid) or {}
        free = n > 0 and not u.get("access") and journal.trial_left(uid) > 0
        on, off = self.TRIAL[self._lang(uid)]
        return self.fn(uid, "cap_hello").replace("{trial}", on.format(n=n) if free else off) + self.t(uid, "disc")

    def step1_rows(self, uid: int) -> list:
        rows = []
        if self.reg_url(uid):
            rows.append([{"text": self.fn(uid, "b_reg"), "url": self.reg_url(uid)}])
        rows.append([{"text": self.fn(uid, "b_check"), "callback_data": "askid"}])
        return rows

    async def trial_over(self, uid: int) -> None:
        n = int(getattr(config, "TRIAL_SIGNALS", 0) or 0)
        cap = self.TRIAL_OVER[self._lang(uid)].format(n=n) + self.fn(uid, "cap_step1") + self.promo(uid)
        await self.card(uid, "f_step1", cap, self.step1_rows(uid))

    # --------------------------------------- «догнать» people who started the bot but never got access --
    RM = {"ru": ("🟢 <b>ARTUR снова в работе — сигналы идут</b>\n\n"
                 "Бот каждый день анализирует рынок Pocket Option и даёт входы по таймеру. Доступ открывается так:\n\n"
                 "1️⃣ Зарегистрируйся по кнопке ниже — <b>новый аккаунт по нашей ссылке</b>\n"
                 "2️⃣ Нажми «Проверить ID» и пришли свой ID трейдера — бот сам сверит регистрацию и откроет доступ.\n\n"
                 "✅ Депозит для доступа <b>не нужен</b>.",
                 "\n\n🔁 Ты уже присылал ID <code>{tid}</code> — нажми «Проверить ID», бот сверит его заново.",
                 "\n\n<i>Торговля связана с риском. Сигналы не гарантируют прибыль. 18+</i>"),
          "ua": ("🟢 <b>ARTUR знову в роботі — сигнали йдуть</b>\n\n"
                 "Бот щодня аналізує ринок Pocket Option і дає входи за таймером. Доступ відкривається так:\n\n"
                 "1️⃣ Зареєструйся за кнопкою нижче — <b>новий акаунт за нашим посиланням</b>\n"
                 "2️⃣ Натисни «Перевірити ID» і надішли свій ID трейдера — бот сам звірить реєстрацію і відкриє доступ.\n\n"
                 "✅ Депозит для доступу <b>не потрібен</b>.",
                 "\n\n🔁 Ти вже надсилав ID <code>{tid}</code> — натисни «Перевірити ID», бот звірить його заново.",
                 "\n\n<i>Торгівля пов'язана з ризиком. Сигнали не гарантують прибутку. 18+</i>"),
          "en": ("🟢 <b>ARTUR is back — signals are running</b>\n\n"
                 "The bot analyses the Pocket Option market every day and gives timed entries. To get access:\n\n"
                 "1️⃣ Sign up with the button below — <b>a new account via our link</b>\n"
                 "2️⃣ Tap «Verify ID» and send your trader ID — the bot checks the registration and opens access.\n\n"
                 "✅ <b>No deposit needed</b> for access.",
                 "\n\n🔁 You already sent ID <code>{tid}</code> — tap «Verify ID» and the bot will check it again.",
                 "\n\n<i>Trading involves risk. Signals do not guarantee profit. 18+</i>")}

    def remind_msg(self, uid: int) -> tuple:
        u = journal.user(uid) or {}
        lang = u.get("lang") if u.get("lang") in self.RM else "ru"
        head, again, foot = self.RM[lang]
        dep = f" от ${config.ACCESS_MIN_DEP:g}" if float(getattr(config, "ACCESS_MIN_DEP", 0) or 0) > 0 else ""
        tid = str(u.get("trader_id") or "")
        cap = head.format(dep=dep) + (again.format(tid=html.escape(tid)) if tid else "") + self.promo(uid) + foot
        rows = []
        if self.reg_url(uid):
            rows.append([{"text": self.fn(uid, "b_reg"), "url": self.reg_url(uid)}])
        rows.append([{"text": self.fn(uid, "b_check"), "callback_data": "askid"}])
        return cap, rows

    def remind_audience(self, who: str) -> list:
        adm = self._admins()
        q = "SELECT uid FROM users WHERE COALESCE(access,0)=0" + (" AND trader_id IS NOT NULL AND trader_id<>''" if who == "ids" else "")
        return [int(r["uid"]) for r in journal._db.execute(q).fetchall() if int(r["uid"]) not in adm and int(r["uid"]) > 1000]

    async def remind_preview(self, admin: int) -> None:
        n_all, n_ids = len(self.remind_audience("all")), len(self.remind_audience("ids"))
        key = "remind:" + time.strftime("%Y%m%d")
        done = set(json.loads(journal.get_setting(key) or "[]"))
        cap, rows = self.remind_msg(admin)
        await self.call("sendMessage", chat_id=admin, parse_mode="HTML",
                        text=(f"📣 <b>Догнать тех, кто без доступа</b>\nБез доступа: <b>{n_all}</b> · из них присылали ID: <b>{n_ids}</b>"
                              + (f"\nСегодня уже получили: {len(done)} (повторно не придёт)" if done else "") + "\n\nТак увидят люди 👇"))
        await self.card(admin, "f_step1", cap, rows)
        await self.call("sendMessage", chat_id=admin, text="Кому отправить?", reply_markup={"inline_keyboard": [
            [{"text": f"📤 Всем без доступа ({n_all})", "callback_data": "rm:all"}],
            [{"text": f"📤 Только кто присылал ID ({n_ids})", "callback_data": "rm:ids"}],
            [{"text": "❌ Отмена", "callback_data": "rm:cancel"}]]})

    async def remind_send(self, admin: int, who: str) -> None:
        key = "remind:" + time.strftime("%Y%m%d")
        done = set(json.loads(journal.get_setting(key) or "[]"))
        ids = [u for u in self.remind_audience(who) if u not in done]
        await self.call("sendMessage", chat_id=admin, text=f"⏳ Отправляю {len(ids)} людям…")
        ok = fail = 0
        for k, uid in enumerate(ids):
            cap, rows = self.remind_msg(uid)
            if await self.card(uid, "f_step1", cap, rows):
                ok += 1
                done.add(uid)
            else:
                fail += 1
            if k % 25 == 24:
                journal.set_setting(key, json.dumps(sorted(done)))
            await asyncio.sleep(0.08)
        journal.set_setting(key, json.dumps(sorted(done)))
        log.info("REMIND %s: sent %d, failed %d", who, ok, fail)
        await self.call("sendMessage", chat_id=admin, parse_mode="HTML",
                        text=f"✅ <b>Готово</b>: доставлено {ok}" + (f" · не доставлено {fail} (заблокировали бота)" if fail else ""))

    def find_users(self, q: str) -> list:
        q = (q or "").strip().lstrip("@")
        if q.isdigit():
            return [dict(r) for r in journal._db.execute("SELECT * FROM users WHERE uid=? OR trader_id=? OR po_trader=?",
                                                          (int(q), q, q)).fetchall()]
        if q:
            return [dict(r) for r in journal._db.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q,)).fetchall()]
        return []

    def whois_text(self, rows: list, q: str) -> str:
        out = []
        for u in rows[:3]:
            tid = str(u.get("trader_id") or u.get("po_trader") or "")
            ev = journal._db.execute("SELECT event, amount FROM pb_log WHERE trader=? ORDER BY ts", (tid or "-",)).fetchall()
            evs = ", ".join(f"{e['event']}{' $%g' % e['amount'] if e['amount'] else ''}" for e in ev[:8]) or "нет"
            out.append(f"👤 {html.escape(u.get('name') or '')} (@{html.escape(u.get('username') or '-')}) · tg <code>{u['uid']}</code>\n"
                       f"Доступ: {'✅ есть' if u.get('access') else '❌ нет'} · Trader ID: <code>{html.escape(tid or '—')}</code>\n"
                       f"Постбэки партнёрки по этому ID: {evs} · депозит ${float(u.get('dep_amount') or 0):g}")
        if not out and q.strip().isdigit():
            ev = journal._db.execute("SELECT event, amount FROM pb_log WHERE trader=? ORDER BY ts", (q.strip(),)).fetchall()
            if ev:
                out.append(f"Trader ID <code>{q.strip()}</code> есть в постбэках ({', '.join(e['event'] for e in ev[:8])}), но к Telegram не привязан.")
        return "\n\n".join(out) or "Не найдено. Пришли tg id, Trader ID или @username."

    def status_text(self) -> str:
        p = hub.provider
        if not p or not hasattr(p, "last_tick"):
            return f"Источник: {config.DATA_SOURCE}"
        now = time.time()
        live = sorted(((now - t, k) for k, t in p.last_tick.items() if now - t < 60))
        fresh = max([getattr(p, "last_ok", 0)] + list(p.last_tick.values()) or [0])
        return (f"🔌 <b>Pocket Option</b>\nСоединение: {'🟢 есть' if p._connected() else '🔴 нет'} · "
                f"данные {now - fresh:.0f} с назад\nЖивых потоков: {len(live)} ({', '.join(k for _a, k in live[:6]) or '—'})\n"
                f"Переподключений с запуска: {getattr(p, 'disconnects', 0)} · неудачных подряд: {getattr(p, '_heal_fail', 0)}\n"
                f"Пар активно: {sum(1 for i in hub.list() if i.active)}\n\nЕсли «нет» держится — пришли свежий <code>/ssid …</code>")

    def pb_text(self) -> str:
        from app import api as A
        rows = getattr(A, "_PB_LAST", [])
        if not rows:
            return ("📭 С момента запуска постбэков от Pocket Partners не было.\n"
                    f"Адрес для кабинета: <code>{html.escape((config.WEBAPP_URL or '').split('/app')[0])}/pb/СЕКРЕТ?event=reg&click={{click_id}}&trader={{trader_id}}&amount={{sumdep}}</code>")
        lines = []
        for t, q in rows[:10]:
            bad = any("{" in str(v) for v in q.values())
            lines.append(f"{'⚠️' if bad else '✅'} {time.strftime('%d.%m %H:%M', time.gmtime(t + 7200))} · " +
                         html.escape(" ".join(f"{k}={v}" for k, v in q.items())))
        return "📨 <b>Последние постбэки</b> (⚠️ = макросы не подставились)\n\n" + "\n".join(lines)

    def _admins(self) -> set:
        s = set(config.ADMIN_IDS)
        if config.COOKIE_ADMIN_ID:
            s.add(config.COOKIE_ADMIN_ID)
        return s

    def _looks_like_cookie(self, text: str) -> bool:
        return text.startswith("/ssid") or text.startswith('42["auth"')

    async def apply_cookie(self, uid: int, text: str) -> None:
        raw = text.split(" ", 1)[1].strip() if text.startswith("/ssid") else text.strip()
        prov = hub.provider
        if not hasattr(prov, "set_ssid"):
            await self.call("sendMessage", chat_id=uid, text="Живой источник сейчас выключен (DATA_SOURCE=mock). SSID не нужен.")
            return
        await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                        text="🔑 SSID принят. Переподключаюсь к Pocket Option — напишу, когда котировки пойдут… (/status)")
        await prov.set_ssid(raw)

    async def alerts_loop(self) -> None:
        """Deliver broker/cookie alerts to the owner only."""
        while True:
            try:
                msg = await hub.alerts.get()
            except Exception:  # noqa: BLE001
                await asyncio.sleep(2); continue
            if msg in ("cookie_down", "pocket_down"):
                text = ("⚠️ <b>Pocket Option не пускает</b> — живые котировки встали (сессия SSID истекла или отклонена).\n\n"
                        "Пришли сюда новую строку SSID одним сообщением: <code>/ssid 42[\"auth\",{…}]</code>\n"
                        "Бери её с отдельного пустого демо-аккаунта Pocket Option.")
            elif msg == "pb_macros":
                text = ("⚠️ <b>Постбэк из Pocket Partners пришёл пустым</b>\n\nВместо ID трейдера пришло <code>{trader_id}</code>, "
                        "вместо метки — <code>{click_id}</code>. Значит, в кабинете Pocket Partners в ссылке постбэка стоят "
                        "макросы, которые партнёрка не подставляет (или это была тестовая отправка).\n\n"
                        "Из-за этого бот не может сам открыть доступ по регистрации. Последние постбэки: /pb")
            elif msg.startswith("cookie_ok") or msg.startswith("pocket_ok"):
                n = msg.split(":", 1)[1] if ":" in msg else "?"
                text = f"✅ <b>Живые котировки пошли</b> — {n} пар, источник Pocket Option."
            elif msg.startswith("ref_join:"):
                _, ref, who = msg.split(":")
                n = html.escape(journal.user(int(who)).get("name") or "Трейдер")
                await self.call("sendMessage", chat_id=int(ref), parse_mode="HTML",
                                text=f"👥 По твоей ссылке пришёл новый трейдер: <b>{n}</b>.\nНаграда начислится, когда он получит доступ и пополнит счёт от ${config.REF_MIN_DEP:.0f}.")
                continue
            else:
                text = "⚠️ " + html.escape(msg)
            for a in self._admins():
                await self.call("sendMessage", chat_id=a, parse_mode="HTML", text=text)

    def funnel_text(self, hours: float = 24) -> str:
        f = journal.funnel(hours)
        head = f"📊 <b>Воронка сигналов за {int(hours)} ч</b>\n\n"
        if not f["total"]:
            return head + "Нажатий «Анализировать» пока не было — считать нечего."
        lines = [f"Анализов: <b>{f['total']}</b> · пользователей: {f['users']}",
                 f"Выдано сигналов: <b>{f['ok']}</b> ({f['share']}%)"]
        for mk, v in sorted(f["by_market"].items()):
            lines.append(f"  {mk}: {v['ok']} из {v['total']} ({round(v['ok'] / v['total'] * 100) if v['total'] else 0}%)")
        lines.append("\n<b>Что отсеяло:</b>")
        for k, n in f["by_key"]:
            if k == "ok":
                continue
            lines.append(f"• {journal.FILTER_RU.get(k, k)} — {n} ({round(n / f['total'] * 100)}%)")
        r = f["results"]
        w, l, d, e = r.get("WIN", 0), r.get("LOSS", 0), r.get("DRAW", 0), r.get("ERROR", 0)
        if w + l + d + e:
            lines.append(f"\n<b>Итоги выданных:</b> WIN {w} · LOSS {l} · DRAW {d}" + (f" · без котировки {e}" if e else "")
                         + (f" → плюсовых {round(w / (w + l) * 100)}%" if w + l else ""))
        sh = f["share"] or 0
        if f["total"] < 30:
            verdict = "Данных пока мало — выводы делать рано (нужно от 30 анализов)."
        elif sh < 10:
            verdict = "🔴 Фильтры слишком жёсткие: сигнал получает меньше 1 из 10. Смотри верхнюю причину — её и ослабляем."
        elif sh <= 35:
            verdict = "🟢 Баланс нормальный: фильтры отсеивают слабые ситуации, но сигналы идут."
        elif sh <= 50:
            verdict = "🟡 Сигналов много — следи за долей плюсовых."
        else:
            verdict = "🔴 Фильтры слишком мягкие: проходит больше половины анализов."
        return head + "\n".join(lines) + "\n\n" + verdict

    async def report_loop(self) -> None:
        """Daily funnel report to admins at REPORT_HOUR_UTC (default 19 UTC = 21:00 Prague summer time)."""
        hour = int(os.getenv("REPORT_HOUR_UTC", "19"))
        while True:
            now = time.time()
            nxt = (now // 86400) * 86400 + hour * 3600
            if nxt <= now:
                nxt += 86400
            await asyncio.sleep(nxt - now)
            try:
                txt = self.funnel_text(24)
                for a in self._admins():
                    await self.call("sendMessage", chat_id=a, parse_mode="HTML", text=txt)
            except Exception as e:  # noqa: BLE001
                log.warning("report failed: %s", e)

    # ------------------------------------------------------------ referrals --
    REF_CAP = ("👥 <b>ПРИГЛАСИ ДРУГА — ПОЛУЧИ ВОЗНАГРАЖДЕНИЕ В $</b>\n\n"
               "Поделись своей персональной ссылкой ARTUR с другом.\n\n"
               "Когда друг зарегистрируется по твоей ссылке и выполнит условия программы, тебе будет начислено "
               "денежное вознаграждение. 💵\n\n"
               "🔗 <b>Как это работает:</b>\n"
               "1. Получи свою персональную ссылку\n2. Отправь её другу\n3. Друг регистрируется по ссылке\n"
               "4. После выполнения условий — получаешь награду в $\n\n"
               "📌 Условие: друг получает доступ к ARTUR и пополняет счёт у брокера от <b>${dep:.0f}</b> — "
               "это нужно для синхронизации и удобной торговли.\n\n"
               "Все приглашения и начисления будут отображаться в твоём профиле ARTUR.")

    def ref_link(self, uid: int) -> str:
        bn = config.BOT_USERNAME or journal.get_setting("bot_username") or ""
        return f"https://t.me/{bn}?start=ref_{uid}"

    def ref_kb(self, uid: int) -> list:
        rows = [[{"text": "🔗 Получить мою ссылку", "callback_data": "ref:link"}],
                [{"text": "👥 Мои приглашения", "callback_data": "ref:inv"}, {"text": "💰 Мои награды", "callback_data": "ref:rew"}]]
        if config.WEBAPP_URL:
            rows.append([{"text": "⚡️ Открыть в ARTUR", "web_app": {"url": config.WEBAPP_URL + "#ref"}}])
        return rows

    async def ref_card(self, uid: int) -> None:
        await self.card(uid, "ref_card", self.REF_CAP.format(dep=config.REF_MIN_DEP), self.ref_kb(uid))

    async def ref_answer(self, uid: int, what: str) -> None:
        st = {"joined": "🆕 перешёл по ссылке", "pending": "⏳ ждёт проверки ID", "access": "✅ доступ · ждём депозит",
              "qualified": "💵 условия выполнены"}
        s = journal.ref_summary(uid)
        if what == "link":
            link = self.ref_link(uid)
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", disable_web_page_preview=True,
                            text=f"🔗 <b>Твоя персональная ссылка ARTUR</b>\n\n<code>{link}</code>\n\nНажми на ссылку, чтобы скопировать, и отправь другу.",
                            reply_markup={"inline_keyboard": [[{"text": "📤 Отправить другу", "url": "https://t.me/share/url?url=" + quote(link, safe="") + "&text=" + quote("⚡️ ARTUR TRADE — присоединяйся по моей ссылке")}]]})
        elif what == "inv":
            if not s["items"]:
                txt = "👥 <b>Мои приглашения</b>\n\nПока никого. Отправь другу свою ссылку — приглашённые появятся здесь."
            else:
                lines = [f"• {html.escape(r['name'] or 'Трейдер')} — {st[r['status']]}" for r in s["items"][:30]]
                txt = (f"👥 <b>Мои приглашения</b> · {s['invited']}\nС доступом: {s['active']} · выполнили условия: {s['qualified']}\n\n"
                       + "\n".join(lines))
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=txt)
        elif what == "rew":
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                            text=(f"💰 <b>Мои награды</b>\n\nНачислено: <b>${s['earned']:.2f}</b>\nВыплачено: ${s['paid']:.2f}\n"
                                  f"К выплате: <b>${s['due']:.2f}</b>\n\nДрузей выполнили условия: {s['qualified']} из {s['invited']}.\n"
                                  f"Награда начисляется, когда друг получил доступ и пополнил счёт от ${config.REF_MIN_DEP:.0f}. "
                                  f"По выплате пиши в поддержку: {html.escape(config.SUPPORT)}"))

    async def refs_admin(self, uid: int) -> None:
        L = journal.ref_leaders()
        W = journal.ref_waiting()
        if not L:
            await self.call("sendMessage", chat_id=uid, text="👥 Партнёрство: приглашений пока нет.")
            return
        lines = [f"• {html.escape(r['name'] or str(r['uid']))} (@{r['username'] or '-'}) — пригласил {r['n']}, доступ {r['a'] or 0}, "
                 f"депозит {r['q'] or 0} · начислено ${r['e']:.0f}, выплачено ${r['paid']:.0f}, <b>к выплате ${r['due']:.0f}</b>" for r in L]
        pay = [[{"text": f"💸 Выплатил {r['name'] or r['uid']} · ${r['due']:.0f}", "callback_data": f"pay:{r['uid']}"}] for r in L if r["due"] > 0]
        await self.call("sendMessage", chat_id=uid, parse_mode="HTML", reply_markup={"inline_keyboard": pay},
                        text="👥 <b>Партнёрство — пригласившие</b>\n\n" + "\n".join(lines))
        if W:
            rows = [[{"text": f"💵 {r['name'] or r['uid']} · ID {r['trader_id']} — депозит от ${config.REF_MIN_DEP:.0f} ✓",
                      "callback_data": f"dep:{r['uid']}"}] for r in W]
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", reply_markup={"inline_keyboard": rows},
                            text=(f"⏳ <b>Ждут подтверждения депозита</b> ({len(W)})\nПроверь Trader ID у брокера и нажми, "
                                  f"если депозит от ${config.REF_MIN_DEP:.0f} есть — пригласившему начислится ${config.REF_REWARD:.0f}."))

    def ref_line(self, uid: int) -> str:
        r = journal.user(uid).get("ref_by")
        if not r:
            return ""
        ru = journal.user(r)
        return f"\n👥 Пригласил: {html.escape(ru.get('name') or '')} (@{ru.get('username') or '-'}) · tg <code>{r}</code>"

    def kb(self, uid: int) -> dict:
        rows = []
        if config.WEBAPP_URL:
            rows.append([{"text": self.t(uid, "open"), "web_app": {"url": config.WEBAPP_URL}, "style": "primary"}])
        if self.reg_url(uid):
            rows.append([{"text": self.t(uid, "reg"), "url": self.reg_url(uid)}])
        if not config.ACCESS_OPEN and not journal.user(uid).get("access"):
            rows.append([{"text": self.t(uid, "id"), "callback_data": "askid"}])
        return {"inline_keyboard": rows}

    async def welcome(self, uid: int, name: str) -> None:
        # Entry point: open the Mini App — the whole funnel (welcome → registration → ID → access) lives inside it.
        await self.call("sendChatAction", chat_id=uid, action="typing")
        await self.loader(uid, "ARTUR", ["Инициализация ядра…", "Подключаемся к брокеру…", "Готово ✅"])
        rows = [[{"text": self.fn(uid, "b_open"), "web_app": {"url": config.WEBAPP_URL}}]]
        await self.card(uid, "f_welcome", self.fn(uid, "cap_welcome") + self.t(uid, "disc"), rows)

    async def ai_report_loop(self) -> None:
        """Daily ARTUR AI report to the admins' DM at REPORT_HOUR (local TIMEZONE, default 21:00)."""
        from app import edge as _E
        while True:
            try:
                tz = ZoneInfo(os.getenv("TIMEZONE") or "Europe/Prague")
                now = datetime.now(tz)
                hr = int(os.getenv("REPORT_HOUR", "21"))
                key = "report:" + now.strftime("%Y%m%d")
                if now.hour >= hr and not journal.get_setting(key):
                    journal.set_setting(key, "1")
                    txt = await asyncio.to_thread(_E.daily, 24)
                    for a in self._admins():
                        await self.call("sendMessage", chat_id=a, parse_mode="HTML", text=txt)
            except Exception as e:  # noqa: BLE001
                log.warning("report loop: %s", e)
            await asyncio.sleep(300)

    async def reqs_loop(self) -> None:
        """Access requests submitted inside the Mini App → owner gets an approve/reject message."""
        while True:
            try:
                r = await hub.reqs.get()
            except Exception:  # noqa: BLE001
                await asyncio.sleep(2); continue
            if r.get("auto") or r.get("metro"):
                # trading messages in the chat are OFF (owner's choice); CHAT_SIGNALS=true turns them back on
                if os.getenv("CHAT_SIGNALS", "false").lower() in ("1", "true", "yes", "on"):
                    if r.get("auto"):
                        asyncio.create_task(self.auto_broadcast(r["auto"], r["wid"]))
                    else:
                        asyncio.create_task(self.metronome(r["metro"]))
                continue
            if r.get("phone_on"):
                asyncio.create_task(self.phone_card(r["phone_on"]))
                continue
            if r.get("trial_over"):
                asyncio.create_task(self.trial_over(r["trial_over"]))
                continue
            if r.get("postback"):
                await self.on_postback(r["uid"], r["postback"], r.get("amount") or 0)
                continue
            n = html.escape(r.get("name") or "")
            un = r.get("username") or "-"
            uid, tid = r["uid"], r["tid"]
            for a in self._admins():
                await self.call("sendMessage", chat_id=a, parse_mode="HTML",
                                text=(f"🆕 <b>Заявка на доступ (Mini App)</b>\n{n} (@{un}) · tg <code>{uid}</code>\n"
                                      f"Trader ID: <code>{tid}</code>"
                                      + ("\n⚠️ Этот Trader ID уже даёт доступ другому Telegram-аккаунту" if r.get("check") == "taken"
                                         else "\nℹ️ В партнёрке ARTUR такого ID нет — проверь вручную")
                                      + self.ref_line(uid)),
                                reply_markup={"inline_keyboard": [[{"text": "✅ Выдать доступ", "callback_data": f"ok:{uid}"},
                                                                    {"text": "❌ Отклонить", "callback_data": f"no:{uid}"}]]})

    async def auto_broadcast(self, what: str, wid: int) -> None:
        """ARTUR AUTO in the chat, personal: a user with pushes ON gets the next window of their track
        (if free) with the full entry plan — times + overlap stakes from their stake — then its result."""
        from app import autofeed as A
        w = A.window(wid)
        if not w:
            return
        buy = w["direction"] == "BUY"
        track = w.get("track") or "normal"
        url = (config.WEBAPP_URL or "") + "#auto" + ("-fast" if track == "fast" else "")
        try:
            tz = ZoneInfo(os.getenv("TIMEZONE") or "Europe/Prague")
        except Exception:  # noqa: BLE001
            tz = None

        def hm(ts):
            return (datetime.fromtimestamp(ts, tz) if tz else datetime.utcfromtimestamp(ts)).strftime("%H:%M:%S")
        L = {
            "ru": {"fast": "⚡ БЫСТРЫЕ СДЕЛКИ", "norm": "ОБЫЧНЫЕ", "sig": "Сигнал", "up": "🟢 ВВЕРХ (BUY)", "dn": "🔴 ВНИЗ (SELL)",
                   "exp": "Время сделки: <b>{e} сек</b> · выплата {p}%", "plan": "План входов (множитель ставки — перекрытие):",
                   "ifl": "если прошлый в минус", "risk": "Если все входы в минус: минус {r} ставки",
                   "disc": "Входи в указанное время. Плюс на любом входе — окно закрыто, дальше не входишь.",
                   "res": "Итог окна", "e": "Вход", "tot": "Итог", "cancel": "ОТМЕНА", "stake": "ставка",
                   "r": {"WIN": "✅ плюс", "LOSS": "❌ минус", "DRAW": "↩️ возврат"}, "noq": "⚠️ нет котировки",
                   "open_s": "⚡️ Открыть в ARTUR", "open": "📊 Открыть ARTUR"},
            "ua": {"fast": "⚡ ШВИДКІ УГОДИ", "norm": "ЗВИЧАЙНІ", "sig": "Сигнал", "up": "🟢 ВГОРУ (BUY)", "dn": "🔴 ВНИЗ (SELL)",
                   "exp": "Час угоди: <b>{e} сек</b> · виплата {p}%", "plan": "План входів (множник ставки — перекриття):",
                   "ifl": "якщо попередній у мінус", "risk": "Якщо всі входи в мінус: мінус {r} ставки",
                   "disc": "Входь у вказаний час. Плюс на будь-якому вході — вікно закрито, далі не входиш.",
                   "res": "Підсумок вікна", "e": "Вхід", "tot": "Підсумок", "cancel": "СКАСОВАНО", "stake": "ставка",
                   "r": {"WIN": "✅ плюс", "LOSS": "❌ мінус", "DRAW": "↩️ повернення"}, "noq": "⚠️ немає котирування",
                   "open_s": "⚡️ Відкрити в ARTUR", "open": "📊 Відкрити ARTUR"},
            "en": {"fast": "⚡ FAST TRADES", "norm": "REGULAR", "sig": "Signal", "up": "🟢 UP (BUY)", "dn": "🔴 DOWN (SELL)",
                   "exp": "Trade time: <b>{e} sec</b> · payout {p}%", "plan": "Entry plan (stake multiplier — overlap):",
                   "ifl": "if the previous one lost", "risk": "If every entry loses: minus {r} of the stake",
                   "disc": "Enter at the given time. A win on any entry closes the window — no more entries.",
                   "res": "Window result", "e": "Entry", "tot": "Total", "cancel": "CANCELLED", "stake": "stake",
                   "r": {"WIN": "✅ win", "LOSS": "❌ loss", "DRAW": "↩️ refund"}, "noq": "⚠️ no quote",
                   "open_s": "⚡️ Open in ARTUR", "open": "📊 Open ARTUR"},
        }
        nums = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣"]

        def money(x):
            return f"{x:.2f}".rstrip("0").rstrip(".")

        def mx(x, base):
            k = x / (base or 1)
            return "×" + (str(round(k)) if abs(k - round(k)) < 0.005 else f"{k:.2f}")

        for uid in journal.push_audience(track):
            u = journal.user(uid)
            t = L.get(u.get("lang") or "ru", L["ru"])
            amount = float(u.get("push_amount") or 10)
            exp = u.get("push_exp") if u.get("push_exp") in w["expiries"] else w["expiries"][-1]
            tt = t["fast"] if track == "fast" else t["norm"]
            if what == "signal":
                if not A.claim_for_push(uid, track, wid, amount, exp):
                    continue            # this user is still in another window
                lad = A.ladder(w["payout"], amount, ["LOSS"] * len(w["plan"]))
                plan = "\n".join(f"{nums[k] if k < len(nums) else k + 1} <b>{hm(p)}</b> — {mx(lad['stakes'][k], amount)}"
                                 + (f" <i>({t['ifl']})</i>" if k else "") for k, p in enumerate(w["plan"]))
                asyncio.create_task(self.countdown(uid, w["plan"][0], f"{'🟢' if buy else '🔴'} <b>{'ВХОДИ' if t is L['ru'] else 'ВХОДЬ' if t is L['ua'] else 'ENTER'}</b> · {html.escape(w['name'])} · {t['up'] if buy else t['dn']}"))
                text = (f"⚡️ <b>ARTUR · {tt} · {t['sig']}</b>\n\n<b>{html.escape(w['name'])}</b> — {t['up'] if buy else t['dn']}\n"
                        + t["exp"].format(e=exp, p=f"{w['payout']:.0f}") + "\n\n" + t["plan"] + "\n" + plan
                        + "\n\n" + t["risk"].format(r=mx(lad["staked"], amount)) + f"\n<i>{t['disc']}</i>")
            else:
                mt = A.my_trade(uid, wid)
                if uid not in A.followers(wid) and not mt:
                    continue
                if w["status"] == "cancelled":
                    text = f"⚠️ <b>{t['res']}: {t['cancel']}</b> · {html.escape(w['name'])}\n{html.escape(w.get('reason') or '')}"
                else:
                    p = A._pnl(w, mt["amount"] if mt else amount, mt["joined"] if mt else 0, mt.get("exp") if mt else exp)
                    lines = "".join(f"\n{t['e']} {a['i']} ({mx(p['stakes'][k], p['stakes'][0] if p['stakes'] else 1)}): {t['r'].get(A.res_of(w, a, p['exp']), t['noq'])}"
                                    for k, a in enumerate(p["played"]))
                    icon = "✅" if p["pnl"] > 0 else "❌" if p["pnl"] < 0 else "↩️"
                    text = (f"{icon} <b>{t['res']}</b> · {html.escape(w['name'])} {'BUY' if buy else 'SELL'} · {p['exp']} {'сек' if t is not L['en'] else 'sec'}\n{lines}"
                            f"\n\n<b>{t['tot']}: {'WIN' if p['pnl'] > 0 else 'LOSS' if p['pnl'] < 0 else 'DRAW'}</b>")
            kb = {"inline_keyboard": [[{"text": t["open_s"] if what == "signal" else t["open"],
                                        "web_app": {"url": url}}]]} if config.WEBAPP_URL else None
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=text,
                            **({"reply_markup": kb} if kb else {}))
            await asyncio.sleep(0.05)          # stay under Telegram's broadcast limit

    # ------------------------------------------------ «Режим одного телефона» --
    # Mirrors EXACTLY what the user has open in the app (manual signal or their auto window): one flow,
    # every message says where it comes from, flips are announced with their time before the entry.
    PT = {
        "ru": {"normal": "📡 ARTUR AUTO · ОБЫЧНЫЕ", "fast": "⚡ ARTUR AUTO · БЫСТРЫЕ", "one": "🎯 ОДИН СИГНАЛ",
               "sys_a": "СИСТЕМА ARTUR · Heikin Ashi", "sys_c": "КЛАССИКА · обычные свечи",
               "sec": "сек", "min": "мин", "ready": "готовь сделку", "at": "Вход {n} в <b>{t}</b>", "at1": "Вход в <b>{t}</b>",
               "now": "сейчас", "up": "⬆️ ВВЕРХ", "dn": "⬇️ ВНИЗ", "go": "ВХОДИ", "flip": "🔄 <b>Разворот</b> в {t}",
               "over": "перекрытие", "same": "направление то же", "loss": "❌ минус", "draw": "↩️ возврат", "win": "✅ плюс",
               "e": "Вход {n}", "res": "Итог", "twin": "✅ <b>ПЛЮС</b>", "tlose": "❌ <b>МИНУС</b>", "err": "⚠️ нет котировки",
               "cancel": "⚠️ Окно отменено", "stop": "⏹ Окно остановлено", "entries": "входов",
               "hint": "Открой у брокера эту пару и время. В момент входа придёт баннер «ВХОДИ» — жми кнопку из него.",
               "off": "⏸ Выключить режим", "offd": "📱 Режим одного телефона выключен."},
        "ua": {"normal": "📡 ARTUR AUTO · ЗВИЧАЙНІ", "fast": "⚡ ARTUR AUTO · ШВИДКІ", "one": "🎯 ОДИН СИГНАЛ",
               "sys_a": "СИСТЕМА ARTUR · Heikin Ashi", "sys_c": "КЛАСИКА · звичайні свічки",
               "sec": "сек", "min": "хв", "ready": "готуй угоду", "at": "Вхід {n} о <b>{t}</b>", "at1": "Вхід о <b>{t}</b>",
               "now": "зараз", "up": "⬆️ ВГОРУ", "dn": "⬇️ ВНИЗ", "go": "ВХОДЬ", "flip": "🔄 <b>Розворот</b> о {t}",
               "over": "перекриття", "same": "напрямок той самий", "loss": "❌ мінус", "draw": "↩️ повернення", "win": "✅ плюс",
               "e": "Вхід {n}", "res": "Підсумок", "twin": "✅ <b>ПЛЮС</b>", "tlose": "❌ <b>МІНУС</b>", "err": "⚠️ немає котирування",
               "cancel": "⚠️ Вікно скасовано", "stop": "⏹ Вікно зупинено", "entries": "входів",
               "hint": "Відкрий у брокера цю пару і час. У момент входу прийде банер «ВХОДЬ» — тисни кнопку з нього.",
               "off": "⏸ Вимкнути режим", "offd": "📱 Режим одного телефону вимкнено."},
        "en": {"normal": "📡 ARTUR AUTO · REGULAR", "fast": "⚡ ARTUR AUTO · FAST", "one": "🎯 SINGLE SIGNAL",
               "sys_a": "ARTUR SYSTEM · Heikin Ashi", "sys_c": "CLASSIC · regular candles",
               "sec": "sec", "min": "min", "ready": "get the trade ready", "at": "Entry {n} at <b>{t}</b>", "at1": "Entry at <b>{t}</b>",
               "now": "now", "up": "⬆️ UP", "dn": "⬇️ DOWN", "go": "ENTER", "flip": "🔄 <b>Reversal</b> at {t}",
               "over": "overlap", "same": "same direction", "loss": "❌ loss", "draw": "↩️ refund", "win": "✅ win",
               "e": "Entry {n}", "res": "Result", "twin": "✅ <b>WIN</b>", "tlose": "❌ <b>LOSS</b>", "err": "⚠️ no quote",
               "cancel": "⚠️ Window cancelled", "stop": "⏹ Window stopped", "entries": "entries",
               "hint": "Open this pair and time at the broker. At the entry second the «ENTER» banner comes — tap the button it names.",
               "off": "⏸ Turn the mode off", "offd": "📱 One-phone mode is off."},
    }

    async def phone_loop(self) -> None:
        """Every second: for each user with the mode ON, follow what they have open. One flow per user."""
        from app import autofeed as A
        self.ph_busy, self.ph_seen, self.ph_last = set(), set(), {}
        lg = logging.getLogger("phone")
        while True:
            await asyncio.sleep(1)
            try:
                now = time.time()
                for uid in journal.phone_audience():
                    if uid in self.ph_busy:
                        continue
                    # 1) a manual signal the user just took in the app (always theirs — they pressed the button)
                    r = journal._db.execute("SELECT id FROM signals WHERE uid=? AND result IS NULL AND entry_at>? "
                                            "ORDER BY id DESC LIMIT 1", (uid, now + 3)).fetchone()
                    if r and ("s", r["id"]) not in self.ph_seen:
                        self.ph_seen.add(("s", r["id"]))
                        self.ph_busy.add(uid)
                        asyncio.create_task(self.phone_manual(uid, r["id"]))
                        continue
                    # 2) the auto track they have open (the same window the app shows them)
                    u = journal.user(uid)
                    track = u.get("push_track") or "normal"
                    if track not in ("normal", "fast"):
                        continue
                    w = A.user_state(uid, track).get("window")
                    if not w or w["status"] not in ("analysis", "signal") or ("w", w["id"]) in self.ph_seen:
                        continue
                    if not w.get("plan") or w["plan"][0] - now < 9:
                        continue                              # too late to get ready — wait for the next one
                    self.ph_seen.add(("w", w["id"]))
                    self.ph_busy.add(uid)
                    asyncio.create_task(self.phone_window(uid, w["id"], track))
                if len(self.ph_seen) > 5000:
                    self.ph_seen = set(list(self.ph_seen)[-1000:])
            except Exception as e:  # noqa: BLE001
                lg.warning("phone loop: %s", e)

    async def phone_card(self, uid: int) -> None:
        """«Режим одного телефона» switched on → a card that also proves the notifications reach the user."""
        lang = journal.user(uid).get("lang") or "ru"
        cap = {"ru": "📱 <b>Режим одного телефона включён</b>\n\nСигналы будут приходить сюда уведомлениями — поверх приложения брокера.\n"
                     "Бот ведёт то, что у тебя открыто в ARTUR: 🎯 один сигнал, 📡 авто обычные или ⚡ авто быстрые.\n\n"
                     "<b>Как входить:</b> «Готовь сделку» → открой пару и время → в секунду входа придёт «ВХОДИ ⬆️/⬇️» — жми кнопку из баннера.\n"
                     "<i>Если это уведомление всплыло у тебя сверху — всё настроено правильно.</i>",
               "ua": "📱 <b>Режим одного телефону увімкнено</b>\n\nСигнали приходитимуть сюди сповіщеннями — поверх застосунку брокера.\n"
                     "Бот веде те, що в тебе відкрито в ARTUR: 🎯 один сигнал, 📡 авто звичайні або ⚡ авто швидкі.\n\n"
                     "<b>Як входити:</b> «Готуй угоду» → відкрий пару і час → у секунду входу прийде «ВХОДЬ ⬆️/⬇️» — тисни кнопку з банера.\n"
                     "<i>Якщо це сповіщення з'явилося згори — все налаштовано правильно.</i>",
               "en": "📱 <b>One-phone mode is on</b>\n\nSignals will arrive here as notifications — on top of the broker app.\n"
                     "The bot follows what you have open in ARTUR: 🎯 single signal, 📡 auto regular or ⚡ auto fast.\n\n"
                     "<b>How to enter:</b> «Get the trade ready» → open the pair and time → at the entry second «ENTER ⬆️/⬇️» comes — tap that button.\n"
                     "<i>If this notification popped up on top — everything is set up right.</i>"}.get(lang)
        t = self._pt(uid)
        await self.card(uid, "f_phone", cap, self._ph_kb(t)["inline_keyboard"])

    def _pt(self, uid):
        return self.PT.get(journal.user(uid).get("lang") or "ru", self.PT["ru"])

    def _ph_kb(self, t):
        return {"inline_keyboard": [[{"text": t["off"], "callback_data": "phone:off"}]]}

    async def _ph_send(self, uid, mids, text, **kw):
        m = await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=text, **kw)
        if m and m.get("message_id") and mids is not None:
            mids.append(m["message_id"])
        return m

    async def _ph_go(self, uid, mids, p, text):
        """«3…» then the ENTER banner exactly at the entry second."""
        lead = float(os.getenv("METRO_LEAD", "0.35"))
        await asyncio.sleep(max(0, p - 3 - time.time()))
        m3 = await self.call("sendMessage", chat_id=uid, text="⏱ 3…")
        await asyncio.sleep(max(0, p - lead - time.time()))
        await self._ph_send(uid, mids, text())
        if m3 and m3.get("message_id"):
            await self.call("deleteMessage", chat_id=uid, message_id=m3["message_id"])

    async def _ph_finish(self, uid, mids, text, t):
        for mid in mids:                                    # steps go away, one result stays
            await self.call("deleteMessage", chat_id=uid, message_id=mid)
        m = await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=text, reply_markup=self._ph_kb(t))
        if m and m.get("message_id"):
            self.ph_last[uid] = m["message_id"]

    async def _ph_clear_last(self, uid):
        old = self.ph_last.pop(uid, None)
        if old:
            await self.call("deleteMessage", chat_id=uid, message_id=old)

    def _ex(self, e, t):
        return f"{e} {t['sec']}" if e < 60 or e % 60 else f"{e // 60} {t['min']}"

    async def phone_window(self, uid: int, wid: int, track: str) -> None:
        from app import autofeed as A
        lg = logging.getLogger("phone")
        t, mids = self._pt(uid), []
        try:
            await self._ph_clear_last(uid)
            w = A.window(wid)
            u = journal.user(uid)
            E = int(u.get("push_exp") or 0)
            if E not in w["expiries"]:
                E = 30 if 30 in w["expiries"] else w["expiries"][-1]
            if not A.my_trade(uid, wid):
                A.join(uid, wid, 10.0, E)
            name, hdr = html.escape(w["name"]), f"{t[track]} · {self._ex(E, t)}"
            d_txt = lambda d: t["up"] if d == "BUY" else t["dn"]          # noqa: E731
            last = w["direction"]
            await self._ph_send(uid, mids, f"<b>{hdr}</b>\n\n<b>{name}</b> — {t['ready']}\n{t['at'].format(n=1, t=self._hm(w['plan'][0]))}"
                                f" · {t['now']} {d_txt(last)}\n\n<i>{t['hint']}</i>", reply_markup=self._ph_kb(t))
            final, n_done, trail = None, 0, []
            for i, p in enumerate(w["plan"], 1):
                # wait until 10 s before the entry — the engine has decided the direction by then
                while time.time() < p - 10:
                    await asyncio.sleep(0.5)
                    if not journal.user(uid).get("phone"):
                        return
                w = A.window(wid)
                if w["status"] == "cancelled":
                    final = f"{t['cancel']} · {html.escape(w.get('reason') or '')}"
                    break
                if i > 1 and w["status"] == "done":        # the engine made no more entries
                    final = t["stop"]
                    break
                d = w["direction"]
                if d != last:
                    await self._ph_send(uid, mids, f"{t['flip'].format(t=self._hm(time.time()))} · <b>{name}</b>\n"
                                        f"{t['at'].format(n=i, t=self._hm(p))} — <b>{d_txt(d)}</b>")
                    last = d
                elif i > 1:
                    await self._ph_send(uid, mids, f"➡️ {t['at'].format(n=i, t=self._hm(p))} — <b>{d_txt(d)}</b> · {t['over']}, {t['same']}")
                await self._ph_go(uid, mids, p, lambda: f"{'🟢' if (A.window(wid) or w)['direction'] == 'BUY' else '🔴'} <b>{t['go']} "
                                  f"{d_txt((A.window(wid) or w)['direction'])}</b> · {name} · {self._ex(E, t)} · {t['e'].format(n=i)}")
                # the user's own result on their expiry
                await asyncio.sleep(max(0, p + E + 1.2 - time.time()))
                r = None
                for _ in range(20):
                    w = A.window(wid)
                    a = w["attempts"][i - 1] if len(w["attempts"]) >= i else None
                    r = A.res_of(w, a, E) if a else None
                    if r:
                        break
                    await asyncio.sleep(0.5)
                n_done = i
                trail.append(f"{t['e'].format(n=i)}: {({'WIN': t['win'], 'LOSS': t['loss'], 'DRAW': t['draw']}).get(r, t['err'])}")
                lg.info("PHONE uid=%s w=%s entry %d %ss %s", uid, wid, i, E, r)
                if r == "WIN":
                    final = t["twin"]
                    break
                if r not in ("LOSS", "DRAW"):
                    final = t["err"]
                    break
            if final is None:
                final = f"{t['tlose']} · {n_done} {t['entries']}"
            await self._ph_finish(uid, mids, f"<b>{hdr}</b> · {name}\n" + "\n".join(trail) + f"\n\n{t['res']}: {final}", t)
        except Exception as e:  # noqa: BLE001
            lg.warning("phone window uid=%s: %s", uid, e)
        finally:
            self.ph_busy.discard(uid)

    async def phone_manual(self, uid: int, sid: int) -> None:
        """A signal the user took in «Один сигнал»: prepare → (reversal) → ENTER → result → next entry of the window."""
        from app import autofeed as A
        from app import api as API
        lg = logging.getLogger("phone")
        t, mids = self._pt(uid), []
        try:
            await self._ph_clear_last(uid)
            s = journal.get(sid)
            art = (s.get("system") == "artur")
            eng = {"artur": "ARTUR HA", "aipro": "AI PRO", "algometric": "ALGOMETRIC"}.get(s["engine"], s["engine"])
            att = int(s.get("attempt") or 1)
            hdr = f"{t['one']} · {t['sys_a'] if art else t['sys_c']} · {eng} · {self._ex(int(s['expiry']), t)}"
            name = html.escape(s["name"])
            d_txt = lambda d: t["up"] if d == "BUY" else t["dn"]          # noqa: E731
            await self._ph_send(uid, mids, f"<b>{hdr}</b>\n\n<b>{name}</b> — {t['ready']}"
                                + (f" · {t['e'].format(n=att)} ({t['over']})" if att > 1 else "")
                                + f"\n{t['at1'].format(t=self._hm(s['entry_at']))} · {t['now']} <b>{d_txt(s['direction'])}</b>"
                                + f"\n\n<i>{t['hint']}</i>", reply_markup=self._ph_kb(t))
            # last look 8 s before the entry: the chart turned while we waited → reversal, announced with its time
            await asyncio.sleep(max(0, s["entry_at"] - 8 - time.time()))
            s = journal.get(sid)
            try:
                if A.FLIP_ON_REVERSE and s.get("entry_price") is None and A.drift_against(s["inst"], s["direction"], float(s.get("created") or s["entry_at"] - 15)):
                    nd = "SELL" if s["direction"] == "BUY" else "BUY"
                    journal._db.execute("UPDATE signals SET direction=? WHERE id=?", (nd, sid))
                    journal._db.commit()
                    await self._ph_send(uid, mids, f"{t['flip'].format(t=self._hm(time.time()))} · <b>{name}</b>\n"
                                        f"{t['at1'].format(t=self._hm(s['entry_at']))} — <b>{d_txt(nd)}</b>")
            except Exception:  # noqa: BLE001
                pass
            await self._ph_go(uid, mids, s["entry_at"], lambda: f"{'🟢' if journal.get(sid)['direction'] == 'BUY' else '🔴'} <b>{t['go']} "
                              f"{d_txt(journal.get(sid)['direction'])}</b> · {name} · {self._ex(int(s['expiry']), t)}")
            await asyncio.sleep(max(0, s["expires_at"] + 1.5 - time.time()))
            for _ in range(20):
                s = journal.get(sid)
                if s.get("result"):
                    break
                await asyncio.sleep(0.5)
            r = s.get("result")
            lg.info("PHONE uid=%s sig=%s %s %s", uid, sid, s["direction"], r)
            res = {"WIN": t["twin"], "LOSS": t["tlose"], "DRAW": t["draw"]}.get(r, t["err"])
            nxt = ""
            if art and r in ("LOSS", "DRAW"):                 # ARTUR window: the next entry follows by itself
                n = max(1, int(float(os.getenv("MAX_ATTEMPTS") or 3)))
                body, _code = API.next_entry(uid, sid, n)
                if body.get("signal"):
                    nxt = "\n➡️ " + t["e"].format(n=att + 1) + f" — {self._hm(body['signal']['entry_at'])} ({t['over']})"
            await self._ph_finish(uid, mids, f"<b>{hdr}</b> · {name} · {d_txt(s['direction'])}\n\n{t['res']}: {res}{nxt}", t)
        except Exception as e:  # noqa: BLE001
            lg.warning("phone manual uid=%s: %s", uid, e)
        finally:
            self.ph_busy.discard(uid)

    def reg_url(self, uid: int) -> str:
        """Personal registration link: the lead id (a<telegram id>) comes back in the broker postback → auto access."""
        try:
            from app.api import ref_url
            return ref_url(uid) or config.AFF_URL
        except Exception:  # noqa: BLE001
            return config.AFF_URL

    def _hm(self, ts: float) -> str:
        try:
            tz = ZoneInfo(os.getenv("TIMEZONE") or "Europe/Prague")
            return datetime.fromtimestamp(ts, tz).strftime("%H:%M:%S")
        except Exception:  # noqa: BLE001
            return datetime.utcfromtimestamp(ts).strftime("%H:%M:%S")

    async def countdown(self, uid: int, entry_at: float, go_text: str) -> None:
        """«3…» then «ВХОДИ» exactly at the entry second (sent ~0.35 s early to cover Telegram delivery)."""
        lead = float(os.getenv("METRO_LEAD", "0.35"))
        await asyncio.sleep(max(0, entry_at - 3 - time.time()))
        m = await self.call("sendMessage", chat_id=uid, text="⏱ 3…")
        await asyncio.sleep(max(0, entry_at - lead - time.time()))
        await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=go_text)
        if m and m.get("message_id"):
            await self.call("deleteMessage", chat_id=uid, message_id=m["message_id"])

    async def metronome(self, sid: int) -> None:
        """Manual signal → the whole entry in the chat: signal, time to enter, 3…, ВХОДИ, then the result."""
        s = journal.get(sid)
        if not s:
            return
        uid, buy = s["uid"], s["direction"] == "BUY"
        lang = journal.user(uid).get("lang") or "ru"
        W = {"ru": ("Сигнал", "ВВЕРХ", "ВНИЗ", "Время сделки", "Сумма", "Вход ровно в", "ВХОДИ СЕЙЧАС", "Итог", "сек"),
             "ua": ("Сигнал", "ВГОРУ", "ВНИЗ", "Час угоди", "Сума", "Вхід рівно о", "ВХОДЬ ЗАРАЗ", "Підсумок", "сек"),
             "en": ("Signal", "UP", "DOWN", "Trade time", "Amount", "Enter exactly at", "ENTER NOW", "Result", "sec")}.get(lang)
        W = W or ("Сигнал", "ВВЕРХ", "ВНИЗ", "Время сделки", "Сумма", "Вход ровно в", "ВХОДИ СЕЙЧАС", "Итог", "сек")
        d = f"{'🟢 ' + W[1] + ' (BUY)' if buy else '🔴 ' + W[2] + ' (SELL)'}"
        head = (f"📍 <b>{W[0]} · {html.escape(s['name'])}</b>\n{d}\n{W[3]}: <b>{s['expiry']} {W[8]}</b>"
                f"\n\n{W[5]} <b>{self._hm(s['entry_at'])}</b>")
        m = await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=head)
        await self.countdown(uid, s["entry_at"], f"{'🟢' if buy else '🔴'} <b>{W[6]}</b> · {html.escape(s['name'])} · {d} · {s['expiry']} {W[8]}")
        await asyncio.sleep(max(0, s["expires_at"] + 3 - time.time()))
        for _ in range(10):
            s = journal.get(sid)
            if s and s.get("result"):
                break
            await asyncio.sleep(1)
        if m and m.get("message_id") and s and s.get("result"):
            icon = {"WIN": "✅", "LOSS": "❌", "DRAW": "↩️"}.get(s["result"], "⚠️")
            await self.call("editMessageText", chat_id=uid, message_id=m["message_id"], parse_mode="HTML",
                            text=head + f"\n\n{icon} <b>{W[7]}: {s['result']}</b> · {s.get('entry_price')} → {s.get('exit_price')}")

    async def on_postback(self, uid: int, what: str, amount: float) -> None:
        """Pocket Option confirmed registration / deposit → tell the trader, open access automatically."""
        u = journal.user(uid)
        who = html.escape(u.get("name") or str(uid))
        lang = u.get("lang") or "ru"
        md, got = f"${config.ACCESS_MIN_DEP:.0f}", f"${float(u.get('dep_amount') or 0):.0f}"
        if what == "reg":
            cap = {"ru": f"✅ <b>Регистрация подтверждена!</b>\n\nШаг 2 из 2 — пополни счёт от <b>{md}</b>.\nДоступ к ARTUR TRADE откроется <b>автоматически</b>, как только депозит зачислится.",
                   "ua": f"✅ <b>Реєстрацію підтверджено!</b>\n\nКрок 2 з 2 — поповни рахунок від <b>{md}</b>.\nДоступ до ARTUR TRADE відкриється <b>автоматично</b>, щойно депозит зарахується.",
                   "en": f"✅ <b>Registration confirmed!</b>\n\nStep 2 of 2 — top up from <b>{md}</b>.\nAccess to ARTUR TRADE opens <b>automatically</b> as soon as the deposit lands."}.get(lang)
            await self.card(uid, "f_regok", cap or "", [[{"text": "💳 Pocket Option", "url": self.reg_url(uid)}]] if self.reg_url(uid) else None)
        elif what == "dep":
            cap = {"ru": f"💳 <b>Депозит получен: {got}</b>\n\nДля доступа нужно от <b>{md}</b> — пополни ещё немного, и доступ откроется сам.",
                   "ua": f"💳 <b>Депозит отримано: {got}</b>\n\nДля доступу потрібно від <b>{md}</b> — поповни ще трохи, і доступ відкриється сам.",
                   "en": f"💳 <b>Deposit received: {got}</b>\n\nAccess needs <b>{md}</b> or more — top up a bit more and it opens by itself."}.get(lang)
            await self.card(uid, "f_moredep", cap or "")
        elif what == "access":
            await self.loader(uid, "ARTUR TRADE", ["Депозит подтверждён…" if amount else "Регистрация подтверждена…", "Открываю доступ…", "Готово ✅"])
            await self.card(uid, "f_access", self.fn(uid, "cap_access") + ("" if float(u.get("dep_amount") or 0) > 0 else self.promo(uid)),
                            [[{"text": self.fn(uid, "b_open"), "web_app": {"url": config.WEBAPP_URL}}]] + await self.priv_rows(uid))
            ref = u.get("ref_by")
            if ref:
                await self.call("sendMessage", chat_id=ref, parse_mode="HTML",
                                text=f"✅ Твой друг {who} получил доступ к ARTUR TRADE.")
        u = journal.user(uid)
        if u.get("ref_by") and float(u.get("dep_amount") or 0) >= config.REF_MIN_DEP and not u.get("dep_ok"):
            ref = journal.ref_qualify(uid, config.REF_REWARD)       # partner reward — automatic via postback
            if ref:
                await self.call("sendMessage", chat_id=ref, parse_mode="HTML",
                                text=f"💵 <b>+${config.REF_REWARD:.0f}</b> — твой друг {who} выполнил условия программы. Награды: /partner")
        what_ru = {"reg": "регистрация", "dep": f"депозит ${amount:g}", "access": (f"депозит ${amount:g} → доступ открыт" if amount else "регистрация → доступ открыт")}[what]
        for a in self._admins():
            await self.call("sendMessage", chat_id=a, parse_mode="HTML",
                            text=f"🔔 Постбэк Pocket Option: <b>{what_ru}</b>\n{who} · tg <code>{uid}</code>"
                                 + (f" · Trader ID <code>{u.get('po_trader')}</code>" if u.get("po_trader") else "")
                                 + self.ref_line(uid))

    async def step1(self, uid: int) -> None:
        rows = []
        if self.reg_url(uid):
            rows.append([{"text": self.fn(uid, "b_reg"), "url": self.reg_url(uid)}])
        rows.append([{"text": self.fn(uid, "b_check"), "callback_data": "askid"}])
        await self.card(uid, "f_step1", self.fn(uid, "cap_step1") + self.promo(uid), rows)

    async def on_message(self, m: dict) -> None:
        uid = m["from"]["id"]
        text = (m.get("text") or "").strip()
        journal.upsert_user(uid, username=m["from"].get("username", ""), name=m["from"].get("first_name", ""))
        # admin → user chat through the bot (works for people without @username)
        if uid in self._admins():
            rp = m.get("reply_to_message") or {}
            target = self._dm_map().get(rp.get("message_id"))
            if not target and rp:
                mt = re.search(r"tg (\d{5,})", rp.get("text") or rp.get("caption") or "")
                target = int(mt.group(1)) if mt else None
            if target:
                await self.dm_send(uid, target, m)
                return
            if text.startswith("/msg"):
                parts = text.split(maxsplit=2)
                rows = self.find_users(parts[1]) if len(parts) > 1 else []
                if len(parts) < 3 or not rows:
                    await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                                    text="✉️ Написать человеку через бота:\n<code>/msg 123456789 текст</code> — tg id, Trader ID или @username.\n"
                                         "Или просто ответь (Reply) на любое сообщение бота, где есть «tg ID» — текст, фото или голосовое уйдут этому человеку.")
                    return
                await self.dm_send(uid, int(rows[0]["uid"]), m, parts[2])
                return
        # owner-only: refresh the broker cookie by pasting it into the chat
        if uid in self._admins() and text and self._looks_like_cookie(text):
            await self.apply_cookie(uid, text)
            return
        if uid in self._admins() and m.get("photo"):
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                            text=("📸 По фото SSID распознаётся ненадёжно (одна ошибка в символе — и сессия недействительна).\n"
                                  "Пришли SSID текстом: <code>/ssid 42[\"auth\",{…}]</code>. "
                                  "Достаточно строки с <code>session_token=…</code>."))
            return
        if text.startswith("/start ref_") and text[11:].isdigit():
            ref = int(text[11:])
            if journal.set_referrer(uid, ref):
                n = html.escape(m["from"].get("first_name", "") or "Трейдер")
                await self.call("sendMessage", chat_id=ref, parse_mode="HTML",
                                text=f"👥 По твоей ссылке пришёл новый трейдер: <b>{n}</b>.\nНаграда начислится, когда он получит доступ и пополнит счёт от ${config.REF_MIN_DEP:.0f}.")
        if text.startswith("/partner"):
            await self.ref_card(uid)
        elif text.startswith("/diag") and uid in self._admins():
            from app.engines import backtest
            await self.call("sendMessage", chat_id=uid, text="🧪 Прогоняю движки по истории котировок…")
            try:
                r = await asyncio.to_thread(backtest.run)
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=backtest.text(r))
            except Exception as e:  # noqa: BLE001
                await self.call("sendMessage", chat_id=uid, text=f"Ошибка самопроверки: {e}")
        elif text.startswith("/refs") and uid in self._admins():
            await self.refs_admin(uid)
        elif text.startswith("/channel") or text.lower() in ("канал", "приват", "channel"):
            if journal.user(uid).get("access") or uid in self._admins():
                await self.priv_send(uid)
            else:
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self._privt(uid)[2])
                await self.step1(uid)
        elif text.startswith("/start"):
            await self.call("sendChatAction", chat_id=uid, action="upload_photo")
            await self.card(uid, "f_hello", self.hello_cap(uid), self.hello_kb(uid))
        elif text.startswith("/funnel") and uid in self._admins():
            parts = text.split()
            hrs = float(parts[1]) if len(parts) > 1 and parts[1].replace(".", "").isdigit() else 24
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self.funnel_text(hrs))
        elif text.startswith("/remind") and uid in self._admins():
            await self.remind_preview(uid)
        elif text.startswith("/report") and uid in self._admins():
            from app import edge as _E
            try:
                hrs = max(1.0, min(720.0, float((text.split() + ["24"])[1])))
            except ValueError:
                hrs = 24.0
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=await asyncio.to_thread(_E.daily, hrs))
        elif text.startswith("/edge") and uid in self._admins():
            from app import edge as _E
            try:
                days = max(1.0, min(60.0, float((text.split() + ["7"])[1])))
            except ValueError:
                days = 7.0
            rep = await asyncio.to_thread(_E.report, days)
            for k in range(0, len(rep), 3800):
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=rep[k:k + 3800])
        elif text.startswith("/pairs") and uid in self._admins():
            from app import radar as _R
            rec, weak = _R.record(7), _R.weak_pairs()
            rows = sorted(((w / (w + lo) * 100, w, lo, k) for k, (w, lo) in rec.items() if w + lo >= 5), reverse=True)
            names = {i.id: i.name for i in hub.list()}
            lines = [f"{'⛔' if k in weak else '🟢' if p >= 55 else '🟡' if p >= 50 else '🔴'} {html.escape(names.get(k, k))}: <b>{p:.0f}%</b> ({w}+/{lo}−)"
                     for p, w, lo, k in rows[:40]]
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                            text=("📊 <b>Проходимость ARTUR по парам · 7 дней</b> (входы AUTO)\n"
                                  "⛔ = доказанно хуже монетки (≥30 входов) — бот такие пары сейчас пропускает\n\n"
                                  + ("\n".join(lines) or "Пока мало данных.")))
        elif text.startswith("/status") and uid in self._admins():
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self.status_text())
        elif text.startswith("/pb") and uid in self._admins():
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self.pb_text())
        elif text.startswith("/whois") and uid in self._admins():
            q = text.split(maxsplit=1)[1] if " " in text else ""
            rows = self.find_users(q)
            kb = None
            if rows:
                u0 = rows[0]
                kb = {"inline_keyboard": [[{"text": "⛔ Отключить доступ", "callback_data": f"no:{u0['uid']}"}] if u0.get("access")
                                          else [{"text": "✅ Выдать доступ", "callback_data": f"ok:{u0['uid']}"}]]}
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self.whois_text(rows, q),
                            **({"reply_markup": kb} if kb else {}))
        elif text.startswith("/revoke") and uid in self._admins():
            rows = self.find_users(text.split(maxsplit=1)[1] if " " in text else "")
            if not rows:
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text="Пришли так: <code>/revoke 123456789</code> (tg id), Trader ID или @username.")
            for u0 in rows[:3]:
                journal.upsert_user(int(u0["uid"]), access=0)
                await self.priv_kick(int(u0["uid"]))
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                                text=f"⛔ Доступ отключён: {html.escape(u0.get('name') or '')} · tg <code>{u0['uid']}</code> (человеку ничего не пришло)",
                                reply_markup={"inline_keyboard": [[{"text": "↩️ Вернуть доступ", "callback_data": f"ok:{u0['uid']}"}]]})
        elif text.startswith("/admin") and uid in self._admins():
            c = journal.counts()
            st = journal.stats()
            rows = [[{"text": f"✅ {r['name'] or r['uid']} · {r['trader_id']}", "callback_data": f"ok:{r['uid']}"},
                     {"text": "❌", "callback_data": f"no:{r['uid']}"}] for r in journal.pending_requests()]
            rows.append([{"text": "📣 Догнать тех, кто без доступа", "callback_data": "rm:preview"}])
            await self.call("sendMessage", chat_id=uid, parse_mode="HTML", reply_markup={"inline_keyboard": rows},
                            text=(f"⚙️ <b>ARTUR — админ</b>\n\nПользователей: {c['users']} · с доступом: {c['access']}"
                                  f" · заявок: {c['pending']}\nЖурнал: {st['total']} сигналов — WIN {st['win']} / "
                                  f"LOSS {st['loss']} / DRAW {st['draw']}\nИсточник: {config.DATA_SOURCE} · "
                                  f"котировки: {'🟢 идут' if hub.cookie_ok and hub.source=='pocketoption' else ('🟡 демо' if hub.source=='mock' else '🔴 нужен SSID')}"
                                  f"\n\nДогнать без доступа: /remind · связь с Pocket: /status · пары за 7 дней: /pairs · где бот в плюсе: <code>/edge 7</code> · отчёт бота: <code>/report 24</code> · постбэки: /pb · человек: <code>/whois ID</code> · отключить: <code>/revoke ID</code>"
                                  f"\nПартнёрство: /refs · воронка сигналов: /funnel · самопроверка: /diag (за сутки) или <code>/funnel 6</code> (за 6 ч)"
                                  f"\nОбновить сессию Pocket Option: <code>/ssid 42[\"auth\",…]</code>"))
        elif uid in self.waiting_id and re.sub(r"\D", "", text) and len(text) <= 40 and not text.startswith("/"):
            text = re.sub(r"\D", "", text)
            if not (5 <= len(text) <= 12):
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                                text=f"🔎 <b>{text}</b> не похож на ID трейдера Pocket Option. Открой Pocket Option → Профиль → ID и пришли эти цифры.")
                return
            self.waiting_id.discard(uid)
            journal.upsert_user(uid, trader_id=text, requested=time.time())
            await self.loader(uid, "ARTUR", self.fn(uid, "chk"))
            res = journal.check_trader(uid, text)       # automatic check against our partner postbacks first
            if res in ("access", "need_dep"):
                await self.on_postback(uid, "access" if res == "access" else "reg", 0)
                return
            await self.card(uid, "f_pending", self.fn(uid, "cap_pending"))
            n = html.escape(m["from"].get("first_name", ""))
            why = ("\n⚠️ Этот Trader ID уже даёт доступ другому Telegram-аккаунту" if res == "taken"
                   else "\nℹ️ В партнёрке ARTUR такого ID нет (регистрировался не по нашей ссылке или раньше постбэков)")
            for a in self._admins():
                await self.call("sendMessage", chat_id=a, parse_mode="HTML",
                                text=f"🆕 <b>Заявка на доступ</b>\n{n} (@{m['from'].get('username', '-')}) · tg <code>{uid}</code>\nTrader ID: <code>{text}</code>" + why + self.ref_line(uid),
                                reply_markup={"inline_keyboard": [[{"text": "✅ Выдать доступ", "callback_data": f"ok:{uid}"},
                                                                    {"text": "❌ Отклонить", "callback_data": f"no:{uid}"}]]})
        elif uid not in self._admins() and not text.startswith("/"):
            await self.dm_in(m)

    # ------------------------------------------------ admin ↔ user messages --
    def _dm_map(self) -> dict:
        return self.__dict__.setdefault("_dm", {})

    async def dm_in(self, m: dict) -> None:
        """A user wrote to the bot → the admins get it with «tg ID»; replying to it answers the user."""
        f = m["from"]
        who = html.escape(f.get("first_name", "") or "Трейдер") + (f" (@{f['username']})" if f.get("username") else " (без @)")
        for a in self._admins():
            h = await self.call("sendMessage", chat_id=a, parse_mode="HTML",
                                text=f"💬 <b>Сообщение в бота</b>\n{who} · tg <code>{f['id']}</code>\n<i>Ответь (Reply) на это или следующее сообщение — бот перешлёт ответ.</i>")
            c = await self.call("copyMessage", chat_id=a, from_chat_id=m["chat"]["id"], message_id=m["message_id"])
            dm = self._dm_map()
            for r in (h, c):
                if r and r.get("message_id"):
                    dm[r["message_id"]] = int(f["id"])
            if len(dm) > 5000:
                for k in list(dm)[:2500]:
                    dm.pop(k, None)

    async def dm_send(self, admin: int, target: int, m: dict, text: str = "") -> None:
        if text:
            r = await self.call("sendMessage", chat_id=target, text=text)
        else:
            r = await self.call("copyMessage", chat_id=target, from_chat_id=m["chat"]["id"], message_id=m["message_id"])
        u = journal.user(target) or {}
        name = html.escape(u.get("name") or str(target))
        await self.call("sendMessage", chat_id=admin, parse_mode="HTML",
                        text=(f"✅ Отправлено: {name} · tg <code>{target}</code>" if r else
                              f"⚠️ Не доставлено: {name} · tg <code>{target}</code> — человек не запускал бота или заблокировал его."))

    async def _dispatch(self, u: dict) -> None:
        src = u.get("message") or u.get("callback_query") or u.get("chat_join_request") or {}
        key = (src.get("from") or src.get("chat") or {}).get("id", 0)
        locks = self.__dict__.setdefault("_ulocks", {})
        lk = locks.get(key)
        if lk is None:
            lk = locks[key] = asyncio.Lock()
        if len(locks) > 5000:
            for k in [k for k, v in list(locks.items()) if not v.locked()][:2500]:
                locks.pop(k, None)
        async with lk:
            try:
                if "message" in u:
                    await self.on_message(u["message"])
                elif "callback_query" in u:
                    await self.on_callback(u["callback_query"])
                elif "chat_join_request" in u:
                    await self.on_join(u["chat_join_request"])
            except Exception as e:  # noqa: BLE001
                log.exception("update failed: %s", e)

    async def on_callback(self, q: dict) -> None:
        uid, data = q["from"]["id"], q.get("data", "")
        await self.call("answerCallbackQuery", callback_query_id=q["id"])
        if data == "phone:off":
            journal.upsert_user(uid, phone=0)
            t = self.PT.get(journal.user(uid).get("lang") or "ru", self.PT["ru"])
            await self.call("sendMessage", chat_id=uid, text=t["offd"])
            return
        if data.startswith("lang:"):
            journal.upsert_user(uid, lang=data[5:])
            msg = q.get("message") or {}
            cap = self.hello_cap(uid)
            if msg.get("message_id"):
                await self.call("editMessageCaption", chat_id=uid, message_id=msg["message_id"], parse_mode="HTML",
                                caption=cap, reply_markup={"inline_keyboard": self.hello_kb(uid)})
            else:
                await self.card(uid, "f_hello", cap, self.hello_kb(uid))
        elif data == "step1":
            await self.step1(uid)
        elif data == "fast":
            if journal.user(uid).get("access") or uid in self._admins():
                await self.priv_send(uid)
            else:
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML", text=self._privt(uid)[2])
                await self.step1(uid)
        elif data.startswith("rm:") and uid in self._admins():
            msg = q.get("message") or {}
            if data == "rm:preview":
                await self.remind_preview(uid)
            else:
                if msg.get("message_id"):
                    await self.call("editMessageReplyMarkup", chat_id=uid, message_id=msg["message_id"], reply_markup={"inline_keyboard": []})
                if data != "rm:cancel" and not getattr(self, "_rm_busy", False):
                    self._rm_busy = True

                    async def _go(who=data[3:]):
                        try:
                            await self.remind_send(uid, who)
                        finally:
                            self._rm_busy = False
                    asyncio.create_task(_go())
                elif data == "rm:cancel":
                    await self.call("sendMessage", chat_id=uid, text="Рассылка отменена.")
        elif data == "askid":
            self.waiting_id.add(uid)
            await self.call("sendMessage", chat_id=uid, text=self.fn(uid, "ask_id"))
        elif data == "partner":
            await self.ref_card(uid)
        elif data.startswith("ref:"):
            await self.ref_answer(uid, data[4:])
        elif data.startswith("dep:") and uid in self._admins():
            target = int(data[4:])
            ref = journal.ref_qualify(target, config.REF_REWARD)
            if ref:
                n = html.escape(journal.user(target).get("name") or "Трейдер")
                await self.call("sendMessage", chat_id=ref, parse_mode="HTML",
                                text=f"💵 <b>+${config.REF_REWARD:.0f}</b> — твой друг {n} выполнил условия программы. Награды: /partner")
                await self.call("sendMessage", chat_id=uid, text=f"✅ Депозит подтверждён: {target} → пригласившему {ref} начислено ${config.REF_REWARD:.0f}")
            else:
                await self.call("sendMessage", chat_id=uid, text="Уже подтверждено или пользователь без пригласившего.")
        elif data.startswith("pay:") and uid in self._admins():
            target = int(data[4:])
            amt = journal.ref_pay(target)
            if amt:
                await self.call("sendMessage", chat_id=target, parse_mode="HTML", text=f"💸 Выплата по партнёрской программе: <b>${amt:.2f}</b>. Спасибо, что с ARTUR!")
            await self.call("sendMessage", chat_id=uid, text=(f"💸 Отмечена выплата ${amt:.2f} → {target}" if amt else "Нечего выплачивать."))
        elif data[:3] in ("ok:", "no:") and uid in self._admins():
            target = int(data[3:])
            ok = data.startswith("ok:")
            journal.upsert_user(target, access=1 if ok else 0, **({} if ok else {"trader_id": None}))
            if ok:
                await self.loader(target, "ARTUR", ["Проверка пройдена…", "Открываю доступ…", "Готово ✅"])
                await self.card(target, "f_access", self.fn(target, "cap_access") + self.promo(target),
                                [[{"text": self.fn(target, "b_open"), "web_app": {"url": config.WEBAPP_URL}}]] + await self.priv_rows(target))
            else:
                await self.priv_kick(target)
                await self.card(target, "f_reject", self.fn(target, "cap_reject"),
                                [[{"text": self.fn(target, "b_retry"), "callback_data": "askid"}]])
            await self.call("sendMessage", chat_id=uid, text=("✅ Выдал доступ" if ok else "❌ Отклонил") + f": {target}")
            ref = journal.user(target).get("ref_by")
            if ok and ref:
                tu = journal.user(target)
                await self.call("sendMessage", chat_id=ref, parse_mode="HTML",
                                text=f"✅ Твой друг {html.escape(tu.get('name') or 'Трейдер')} получил доступ к ARTUR. Награда начислится после его пополнения от ${config.REF_MIN_DEP:.0f}.")
                await self.call("sendMessage", chat_id=uid, parse_mode="HTML",
                                text=f"👥 Это приглашённый пользователь. Когда увидишь у брокера депозит от ${config.REF_MIN_DEP:.0f} по ID <code>{tu.get('trader_id')}</code> — подтверди:",
                                reply_markup={"inline_keyboard": [[{"text": f"💵 Депозит от ${config.REF_MIN_DEP:.0f} есть — начислить ${config.REF_REWARD:.0f}", "callback_data": f"dep:{target}"}]]})

    async def run(self) -> None:
        if not config.BOT_TOKEN:
            log.info("BOT_TOKEN not set — bot disabled (mini app works in browser demo mode)")
            return
        me = await self.call("getMe")
        if me and me.get("username"):
            journal.set_setting("bot_username", me["username"])
        await self.call("setMyCommands", commands=[{"command": "start", "description": "🚀 ARTUR TRADE"},
                                                   {"command": "partner", "description": "👥 Пригласи друга — награда в $"}])
        # bot profile & preview
        await self.call("setMyName", name=os.getenv("BOT_NAME", "ARTUR TRADE"))
        await self.call("setMyShortDescription",
                        short_description="Аналитика OTC и Forex под Pocket Option: живые котировки, сигналы, честный журнал. 18+")
        await self.call("setMyDescription",
                        description=("ARTUR TRADE — торговая система для Pocket Option.\n\n"
                                     "• Живые котировки OTC и Forex, все пары и таймфреймы\n"
                                     "• Движок ARTUR HA: Heikin Ashi + 8 фильтров + EMA/RSI/MACD и режим рынка\n"
                                     "• Разбор сигнала по факторам и честный журнал: плюсы и минусы\n\n"
                                     "Жми «Запустить», пройди быстрый вход и получи доступ. Сигналы — аналитика, не гарантия. 18+"))
        if config.WEBAPP_URL:
            await self.call("setChatMenuButton", menu_button={"type": "web_app", "text": "ARTUR TRADE",
                                                              "web_app": {"url": config.WEBAPP_URL}})
        asyncio.create_task(self.alerts_loop())
        asyncio.create_task(self.reqs_loop())
        asyncio.create_task(self.ai_report_loop())
        asyncio.create_task(self.phone_loop())
        asyncio.create_task(self.report_loop())
        off = 0
        while True:
            try:
                r = await self.c.get(f"{API}/getUpdates", params={"offset": off, "timeout": 30,
                                                                 "allowed_updates": json.dumps(["message", "callback_query", "chat_join_request"])})
                for u in r.json().get("result", []):
                    off = u["update_id"] + 1
                    asyncio.create_task(self._dispatch(u))      # users in parallel, one user's updates in order
            except Exception as e:  # noqa: BLE001
                log.warning("polling: %s", e)
                await asyncio.sleep(3)
