"""Entry point: quotes provider + bot + HTTP server in one process."""
from __future__ import annotations

import asyncio
import json
import os
import time
import logging

import uvicorn

from app import config, journal
from app.api import app as web
from app.bot import Bot
from app.market.hub import hub

logging.basicConfig(level=logging.INFO, force=True, format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("main")
logging.getLogger("httpx").setLevel(logging.WARNING)   # never print the bot token in logs


def make_provider():
    if config.DATA_SOURCE in ("pocket", "pocketoption"):
        from app.market.pocket import PocketProvider
        return PocketProvider(hub)
    from app.market.mock import MockProvider
    log.warning("DATA_SOURCE=mock — DEMO quotes, not market data")
    return MockProvider(hub)


async def selfcheck() -> None:
    """Replay the engines on stored broker history → win-rate per filter mode in the log (and /diag)."""
    from app.engines import backtest
    await asyncio.sleep(180)
    while True:
        try:
            # grow the sample: subscribe a few pairs that have no history yet (broker sends ~200 1m candles)
            if hub.provider and hub.source == "comfortrade":  # (pocket: history for all pairs is polled anyway)
                cold = [i for i in hub.list() if i.active and len(hub.candles(i.id, 60, 200)) < 120][:8]
                for i in cold:
                    await hub.provider.want(i.id)
                    await asyncio.sleep(0.7)
                if cold:
                    await asyncio.sleep(6)
            r = await asyncio.to_thread(backtest.run)
            backtest.log_line(r)
            f = journal.funnel(24)
            log.info("FUNNEL24 total=%s ok=%s share=%s by=%s", f["total"], f["ok"], f["share"], f["by_key"])
        except Exception as e:  # noqa: BLE001
            log.warning("selfcheck failed: %s", e)
        await asyncio.sleep(1800)


async def accuracy_report() -> None:
    """Every 30 min: real accuracy of signals by trade time and strength (last 24 h) → logs, to tune what works."""
    await asyncio.sleep(300)
    while True:
        try:
            since = time.time() - 86400
            rows = journal._db.execute("SELECT expiry, factors, COALESCE(my_result, result) AS r FROM signals "
                                       "WHERE created>=? AND COALESCE(my_result, result) IN ('WIN','LOSS')", (since,)).fetchall()
            agg: dict = {}
            for r in rows:
                try:
                    st = (json.loads(r["factors"] or "{}") or {}).get("strength") or "?"
                except Exception:  # noqa: BLE001
                    st = "?"
                for k in (f"exp={r['expiry']}s", f"strength={st}", f"exp={r['expiry']}s/{st}"):
                    a = agg.setdefault(k, [0, 0])
                    a[0 if r["r"] == "WIN" else 1] += 1
            line = " · ".join(f"{k}: {w}/{w + l} = {round(w / (w + l) * 100)}%" for k, (w, l) in sorted(agg.items()))
            log.info("ACCURACY24 signals=%d %s", len(rows), line or "—")
            from app import autofeed as A
            for tr in ("normal", "fast"):
                for e in A.TRACKS[tr]["expiries"]:
                    st = A.stats(24, tr, e)
                    log.info("ACCURACY24 auto[%s%s] windows %s/%s entries %s%% (be %s%%)", tr, f" {e}s" if e else "",
                             st["win"], st["win"] + st["loss"], st["entries_share"], st["breakeven"])
        except Exception as e:  # noqa: BLE001
            log.warning("accuracy report failed: %s", e)
        await asyncio.sleep(1800)


def purge_users() -> None:
    """One-time clean start (PURGE_USERS_KEEP_ADMINS=1): remove every user except the admins, with their
    signals/trades. A full DB backup is written first; a marker file makes sure it runs only once."""
    import logging
    import sqlite3
    lg = logging.getLogger("purge")
    if os.getenv("PURGE_USERS_KEEP_ADMINS", "").lower() not in ("1", "true", "yes", "on"):
        return
    keep = {int(x) for x in config.ADMIN_IDS} | ({config.COOKIE_ADMIN_ID} if config.COOKIE_ADMIN_ID else set())
    mark = config.DB_PATH + ".purged"
    if not keep or os.path.exists(mark):
        lg.info("PURGE skipped (admins=%s, done before=%s)", sorted(keep), os.path.exists(mark))
        return
    bak = f"{config.DB_PATH}.bak-{int(time.time())}"
    dst = sqlite3.connect(bak)
    journal._db.backup(dst)
    dst.close()
    q = ",".join("?" * len(keep))
    counts = {}
    for t in ("users", "signals", "auto_trades", "attempts", "sessions", "ref_payouts"):
        try:
            counts[t] = journal._db.execute(f"DELETE FROM {t} WHERE uid NOT IN ({q})", tuple(keep)).rowcount
        except Exception as e:  # noqa: BLE001
            counts[t] = f"skip: {e}"
    try:                                               # admins keep their account, their invites are gone
        journal._db.execute(f"UPDATE users SET ref_by=NULL WHERE uid IN ({q})", tuple(keep))
    except Exception:  # noqa: BLE001
        pass
    journal._db.commit()
    open(mark, "w").write(str(time.time()))
    lg.info("PURGE done: kept admins %s, deleted %s, backup %s", sorted(keep), counts, bak)


async def main() -> None:
    hub.provider = make_provider()
    asyncio.create_task(hub.provider.run())
    journal.recover()
    purge_users()
    if os.getenv("SELFCHECK", "false").lower() in ("1", "true", "yes", "on"):   # heavy history replay: off by default
        asyncio.create_task(selfcheck())
    if os.getenv("AUTO_ENABLED", "true").lower() in ("1", "true", "yes", "on"):
        from app import autofeed
        asyncio.create_task(autofeed.loop())
    asyncio.create_task(accuracy_report())
    try:                                          # ARTUR FAST SIGNALS: HA M3/M5 channel (needs ARTFS_CHAT_ID)
        from app import artfs as _artfs
        if _artfs._on() and _artfs.chat_id():
            asyncio.create_task(_artfs.loop())
    except Exception as e:  # noqa: BLE001
        logging.getLogger("main").warning("artfs off: %s", e)
    try:                                          # POSTER: separate bot for the admin's own channel posts
        from app import poster as _poster
        if _poster.TOKEN:
            asyncio.create_task(_poster.loop())
    except Exception as e:  # noqa: BLE001
        logging.getLogger("main").warning("poster off: %s", e)
    from app import radar as _radar
    asyncio.create_task(_radar.news_loop())
    asyncio.create_task(Bot().run())
    server = uvicorn.Server(uvicorn.Config(web, host="0.0.0.0", port=config.PORT, log_level="warning"))
    log.info("ARTUR up on :%d (source=%s)", config.PORT, config.DATA_SOURCE)
    await server.serve()


if __name__ == "__main__":
    asyncio.run(main())
