"""ARTUR FAST SIGNALS — Heikin Ashi M3 / M5 signals with 3 / 5 second trades for Pocket Option, posted 24/7 to the
ARTUR private channel. Same flow and texts as CONTROL FAST SIGNALS: analysis → signal (up to 5 entries) → result as a
reply with statistics; «Checking new signal...» heads-up once an hour.

Runs inside the ARTUR bot (it already holds the Pocket Option quotes). Read-only: never trades. The pair of the running
signal is pinned so its live tick stream stays on; entries are settled on the last tick at or before each boundary.
Env: ARTFS_ENABLED (default on), ARTFS_CHAT_ID (channel id, required), ARTFS_BOT_TOKEN (default BOT_TOKEN),
ARTFS_ENTRIES, ARTFS_STAKE_PCT, ARTFS_CONTACT, ARTFS_PAUSE, ARTFS_PREP, ARTFS_LEAD, ARTFS_MIN_SCORE, ARTFS_MIN_PAYOUT.
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

from app import journal

log = logging.getLogger("artfs")
KYIV = ZoneInfo("Europe/Kyiv")
IMG = Path(__file__).resolve().parent.parent / "web" / "img" / "artfs"
_CACHE: dict = {}


def _on() -> bool:
    return os.getenv("ARTFS_ENABLED", "true").lower() in ("1", "true", "yes", "on")


def _i(n: str, d: int) -> int:
    try:
        return int(float(os.getenv(n) or d))
    except ValueError:
        return d


FROM, TO = _i("ARTFS_FROM", 0), _i("ARTFS_TO", 24)          # 0/24 = 24/7 (CONTROL FAST SIGNALS)
MORNING = _i("ARTFS_MORNING", 9)
PER_DAY = max(1, _i("ARTFS_PER_DAY", 17 if (FROM <= 0 and TO >= 24) else 10))   # same rhythm as 10 in 09–23: one per ~85 min                              # «good morning» post, Ukraine time

ENTRIES = max(1, min(5, _i("ARTFS_ENTRIES", 5)))
STAKE = max(1, _i("ARTFS_STAKE_PCT", 3))
CONTACT = os.getenv("ARTFS_CONTACT", "@ArturTreider")
MONEY = _i("ARTFS_MONEY", 100)          # result posts count every entry with this stake in $
WARN_EVERY = _i("ARTFS_WARN_EVERY", 3600)    # «signal within 5–35 min» post: once an hour
PAUSE = _i("ARTFS_PAUSE", 8)                # seconds between a result and the next search
MIN_SCORE = float(os.getenv("ARTFS_MIN_SCORE", "12.5"))   # stricter HA setups only (max ≈ 19)
LEARN: dict = {}
PREP = _i("ARTFS_PREP", 20)                   # analysis (pair) → signal (direction): time to open the pair
LEAD = _i("ARTFS_LEAD", 40)                   # signal → first entry: at least this many seconds


def h24() -> bool:
    return FROM <= 0 and TO >= 24


def in_hours(now: Optional[float] = None) -> bool:
    if h24():
        return True
    h = datetime.fromtimestamp(now or time.time(), KYIV).hour
    return FROM <= h < TO


def gap_seconds() -> float:
    hours = 24 if h24() else max(1, TO - FROM)
    return hours * 3600 / PER_DAY


# ------------------------------------------------------------------ text helpers
def hms(ts: float) -> str:
    return datetime.fromtimestamp(ts, KYIV).strftime("%H:%M:%S")


def hm(ts: float) -> str:
    return datetime.fromtimestamp(ts, KYIV).strftime("%H:%M")


def exp_lbl(sec) -> str:
    sec = int(sec or 60)
    return f"{sec // 60} MIN" if sec >= 60 and sec % 60 == 0 else f"{sec} SEC"


def tf_of(w: dict) -> str:
    return ((w.get("factors") or {}).get("ha") or {}).get("tf") or "S30"


def trade_tag(w: dict) -> str:
    return f"{exp_lbl(w.get('expiry'))} • {tf_of(w)}"


def pair(w: dict) -> str:
    return html.escape(w.get("name") or w.get("inst") or "")


def dir_txt(d: str) -> str:
    return "BUY (вверх) 📈" if d == "BUY" else "SELL (вниз) 📉"


def contact() -> str:
    return f"✍️ <i>По всем вопросам:</i> {html.escape(CONTACT)}"


def plan_of(w: dict) -> list:
    """The channel's own entry plan: the AUTO window's entries, continued with the same step up to ENTRIES.
    The Mini App window is never changed — extra entries are resolved by the channel itself on real prices."""
    p = list(w.get("plan") or [])[:ENTRIES]
    if not p:
        return []
    exp = int(w.get("expiry") or 60)
    step = (p[1] - p[0]) if len(p) > 1 else max(30, -(-(exp + 20) // 5) * 5)
    while len(p) < ENTRIES:
        p.append(p[-1] + step)
    return p


def entry_sec(w: dict) -> str:
    p = plan_of(w)
    return f":{datetime.fromtimestamp(p[0], KYIV).second:02d}" if p else ":30"


def howto(w: Optional[dict] = None) -> str:
    tag = trade_tag(w) if w else "по системе"
    tf = tf_of(w) if w else "S30"
    p = plan_of(w) if w else []
    ex = (f"Окно с {hms(p[0])} до {hms(p[-1])}. " if p else "")
    return (f"Система: Heikin Ashi {tf} · вход на {entry_sec(w) if w else ':30'} · {tag}\n"
            f"{ex}Входим ровно в указанное время. Не зашла сделка — следующий вход по плану, до {ENTRIES} входов. "
            f"Как только сделка закрылась в плюс — стоп, ждём следующий сигнал.\n"
            f"💰 Ставка всегда одна и та же — {STAKE}% от депозита, после минуса не увеличиваем.\n"
            "🛑 3 минусовых окна за день — на сегодня стоп.")


def cap_day() -> str:
    hrs = "круглосуточно (24/7)" if h24() else f"с {FROM:02d}:00 до {TO:02d}:00"
    return ("☀️ <b>ДОБРОЕ УТРО, КОМАНДА!</b>\nНачинаем торговый день — готовимся к сделкам 💪\n\n"
            "➡️ <b>План на сегодня:</b>\n<blockquote>"
            f"• 📊 Сигналы идут без остановки {hrs}, новый — через пару минут после итога (🇺🇦 Украина)\n"
            "• ⏳ Время сделки: 3 / 5 SEC · таймфрейм M3 / M5 — система выбирает под сетап, о смене предупредим\n"
            f"• 🎯 Вход по времени из сигнала, до {ENTRIES} входов\n"
            "• 🚨 Раз в час — напоминание и статистика</blockquote>\n\n"
            "➡️ <b>Проверь заранее:</b>\n<blockquote>• 📲 Доступ к платформе\n• 💴 Баланс\n• 📶 Соединение</blockquote>\n\n"
            + contact())


def cap_rules() -> str:
    return ("❓ <b>Как торгуем по сигналам</b> 👇\n\n"
            "📊 <b>Система сигналов / Настройки</b>\n<blockquote>"
            "Свечи Heikin Ashi · таймфрейм и время сделки — в каждом сигнале\n"
            "Каждый сигнал содержит торговое окно, например: 19:17:30 – 19:18:30\n"
            "Вход выполняется ровно во время из сигнала (время — 🇺🇦 Украина).</blockquote>\n\n"
            f"Пример входов (депозит 100$ → ставка {STAKE}$ на КАЖДЫЙ вход): 👇\n<blockquote>"
            f"1️⃣ Не зашла первая 🚫 Ставили {STAKE}$ — идём на следующий вход.\n"
            f"2️⃣ Следующий вход, ставили {STAKE}$. Забрали ➕ ☑️</blockquote>\n\n"
            "❗️ Как только любая сделка закрывается в плюс — сразу останавливаемся и ждём следующий сигнал в канале.\n\n"
            f"💰 Ставка всегда одна и та же — {STAKE}% от депозита. После минуса сумму не увеличиваем.\n"
            "🛑 3 минусовых окна за день — на сегодня стоп.\n"
            "При выплате ~85% гарантий нет — торгуйте только суммой, которую готовы потерять.")


def cap_warn(stats: str = "") -> str:
    return ("🚨 <b>СИГНАЛ В ТЕЧЕНИЕ 5–35 МИНУТ</b>\n<blockquote><b>📊 Приготовьтесь — вход будет совсем скоро.</b></blockquote>\n\n"
            "➡️ <b>Проверь заранее:</b>\n<blockquote><b>• 📲 Доступ к платформе\n• 💴 Баланс для торговли\n• 📶 Стабильное соединение</b></blockquote>\n\n"
            + contact() + ("\n\n<blockquote><b>🗣 Checking new signal...</b></blockquote>\n"
                           f"<blockquote><b>{stats}</b></blockquote>" if stats else ""))


def cap_analysis(w: dict) -> str:
    return ("🧠 <b>АНАЛИЗ СИГНАЛА. ОТБОР ПО СИСТЕМЕ</b>\n\n"
            f"💱 Пара: <b>{pair(w)}</b>\n<blockquote>✅ Heikin Ashi {tf_of(w)}: серия свечей одного цвета\n✅ Сильное тело, без встречных теней\n"
            f"✅ Живые котировки, выплата {round(w.get('payout') or 0)}%</blockquote>\n\n"
            f"📋 Параметры входа: график {tf_of(w)} · время сделки {trade_tag(w)} · до {len(plan_of(w))} входов\n\n"
            "Откройте пару у брокера, выставьте график и время сделки — <b>сигнал с направлением придёт меньше чем через минуту</b> ⏳")


NUMS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"]


def cap_signal(w: dict) -> str:
    p = plan_of(w)
    dot = "🟢" if w["direction"] == "BUY" else "🔴"
    return (f"{dot} <b>СИГНАЛ ПО {pair(w)}</b>\n"
            f"<blockquote><b>⚡ Сегодняшний вход:\n🇺🇦 Украина — {hms(p[0])}" + (f" до ({hms(p[-1])})" if len(p) > 1 else "") + "</b></blockquote>\n\n"
            "<blockquote><b>➡️ Детали сигнала:\n"
            f"• 📈 Пара: {pair(w)}\n• 🎯 Сделка: {dir_txt(w['direction'])}\n"
            f"• ⏳ Время сделки: {trade_tag(w)}\n• 💰 Ставка: {STAKE}% от депозита</b></blockquote>\n\n"
            f"<blockquote expandable><b>➡️ Как делать сделки с нами</b> <i>(разверни 👇)</i>\n<b>Система:</b> Heikin Ashi {tf_of(w)}\n<b>Время сделки:</b> {exp_lbl(w.get('expiry'))}\n"
            "⏱ <b>Входы по плану:</b>\n" + "\n".join(f"{NUMS[k] if k < len(NUMS) else str(k + 1) + '.'} {hms(t)}" for k, t in enumerate(p))
            + "\n✅ После WIN прекращаем входы.\n⚠️ После минуса ставку не повышаем.</blockquote>\n\n"
            + contact())


def result_of(w: dict) -> tuple:
    """(final, lines, profit of the winning entry, window total) for the first ENTRIES entries, stake = STAKE $."""
    at = [a for a in (w.get("attempts") or []) if a.get("result")][:ENTRIES]
    pay = float(w.get("payout") or 85) / 100
    lines, total, win = [], 0.0, None
    for a in at:
        r = a["result"]
        mark = "☑️" if r == "WIN" else "🚫" if r == "LOSS" else "⚪"
        lines.append(f"Время отработки: {hms(a['entry_at'])}/{tf_of(w)}{mark}")
        total += MONEY * pay if r == "WIN" else -MONEY if r == "LOSS" else 0
        if r == "WIN":
            win = a
            break
    if win:
        return "WIN", lines, MONEY * pay, total, win
    if at and all(a["result"] == "DRAW" for a in at):
        return "DRAW", lines, 0.0, total, None
    return ("LOSS" if at else None), lines, 0.0, total, None


def cap_result(w: dict) -> Optional[tuple]:
    fin, lines, prof, total, win = result_of(w)
    if not fin:
        return None
    d = w["direction"]
    if fin == "WIN":
        head = f"✅ <b>WIN НА {win.get('i', 1) if win else 1}-М ВХОДЕ</b>"
    elif fin == "DRAW":
        head = "⚪ <b>ВОЗВРАТ — цена закрылась на уровне входа</b>"
    else:
        head = f"❌ <b>LOSS — {len(lines)} ИЗ {len(lines)} ВХОДОВ В МИНУС</b>" if len(lines) > 1 else "❌ <b>LOSS</b>"
    return fin, (f"{head}\n\n"
                 f"<blockquote>💱 <b>{pair(w)}</b> — {dir_txt(d)}\n⌛ <b>{trade_tag(w)}</b></blockquote>\n\n"
                 "<blockquote><b>" + "\n".join(lines) + "</b></blockquote>\n\n"
                 "<blockquote><b>⏱ Итог считаем по точному времени входа из сигнала — секунда в секунду.</b>\n"
                 "<i>Вошли на 1–2 секунды позже — ваш результат у брокера может отличаться.</i></blockquote>\n\n"
                 + contact())


def cap_time_change(old: int, new: int, w: dict, why: str) -> str:
    return ("⏱ <b>СМЕНА ВРЕМЕНИ СДЕЛКИ</b>\n\n<blockquote>"
            f"⏱ Время сделки: {exp_lbl(old)} • {tf_of(w)} → {exp_lbl(new)} • {tf_of(w)}\n"
            f"📊 Таймфрейм: {tf_of(w)} без изменений</blockquote>\n\n"
            f"🕐 Вступает в силу:\n🇺🇦 Украина {hms(plan_of(w)[0]) if plan_of(w) else hm(time.time())} — со следующего сигнала\n"
            "⏳ Выставьте новое время сделки на платформе\n\n"
            f"📈 Причина: {html.escape(why)}")


def cap_mode_change(old: str, new: str, w: dict) -> str:
    return ("⚙️ <b>СМЕНА РЕЖИМА</b>\n\n<blockquote>"
            f"📊 Таймфрейм Heikin Ashi: {old} → {new}\n⏱ Время сделки: {trade_tag(w)}</blockquote>\n\n"
            f"🕐 Вступает в силу: 🇺🇦 Украина {hms(plan_of(w)[0]) if plan_of(w) else hm(time.time())} — со следующего сигнала\n"
            "Переключите график на новый таймфрейм.\n\n"
            "📈 Причина: система подстроилась под текущую скорость рынка")


def stats_line(s: dict, day: str) -> str:
    """Real counts of the signals published in this channel: a window is ➕ if any entry won, ➖ if all its entries lost."""
    al = s.get("all") or {"w": 0, "l": 0}
    td = s.get("today") or {}
    tw, tl = (td.get("w", 0), td.get("l", 0)) if td.get("d") == day else (0, 0)
    return f"📊 Общая статистика: {al['w']} ➕ {al['l']} ➖\nСегодня: {tw} ➕ {tl} ➖"


# ------------------------------------------------------------------ telegram
def card(name: str) -> bytes:
    if name not in _CACHE:
        _CACHE[name] = (IMG / f"{name}.jpg").read_bytes()
    return _CACHE[name]


MAIN_URL = ""                                             # ARTUR: quotes come from this process's own hub
TOKEN = os.getenv("ARTFS_BOT_TOKEN") or os.getenv("BOT_TOKEN", "")
CHAT: dict = {"id": None}


def chat_id():
    v = (os.getenv("ARTFS_CHAT_ID") or "").strip()
    try:
        return int(v) if v else None
    except ValueError:
        return None


async def _tg(method: str, data: dict, files: Optional[dict] = None) -> Optional[dict]:
    import httpx
    if not TOKEN or not chat_id():
        return None
    data = dict(data, chat_id=str(chat_id()))
    for attempt in range(3):                                 # a network hiccup must not lose a signal post
        try:
            async with httpx.AsyncClient(timeout=40) as c:
                r = (await c.post(f"https://api.telegram.org/bot{TOKEN}/{method}", data=data, files=files)).json()
            if r.get("ok"):
                return r.get("result")
            log.warning("ARTFS %s: %s", method, r.get("description"))
            if "retry after" not in str(r.get("description", "")).lower():
                return None
        except Exception as e:  # noqa: BLE001
            log.warning("ARTFS %s failed (try %d): %r", method, attempt + 1, e)
        await asyncio.sleep(2 + 3 * attempt)
    return None


def _reply(reply_to: Optional[int]) -> dict:
    return {"reply_parameters": json.dumps({"message_id": reply_to, "allow_sending_without_reply": True})} if reply_to else {}


async def photo(name: str, caption: str, reply_to: Optional[int] = None) -> Optional[int]:
    files = {"photo": (f"{name}.jpg", card(name), "image/jpeg")}
    if len(caption) <= 1024:
        m = await _tg("sendPhoto", {"caption": caption, "parse_mode": "HTML", **_reply(reply_to)}, files)
        return (m or {}).get("message_id")
    m = await _tg("sendPhoto", _reply(reply_to), files)      # long caption: card alone, text as a reply
    if m:
        await text(caption, reply_to=m.get("message_id"))
    return (m or {}).get("message_id")


async def text(t: str, reply_to: Optional[int] = None) -> Optional[int]:
    m = await _tg("sendMessage", {"text": t, "parse_mode": "HTML", "link_preview_options": json.dumps({"is_disabled": True}),
                                  **_reply(reply_to)})
    return (m or {}).get("message_id")


# ------------------------------------------------------------------ quotes: local hub or the Mini App server (read only)
async def _get(path: str, **params) -> Optional[dict]:
    import httpx
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.get(MAIN_URL + path, params=params)
        return r.json() if r.status_code == 200 else None
    except Exception as e:  # noqa: BLE001
        log.warning("ARTFS quotes %s: %s", path, e)
        return None


async def market() -> list:
    """[{id, name, payout, last: [price, ts], c: {tf: candles}}] for every active pair."""
    if MAIN_URL:
        d = await _get("/api/fs/scan")
        if not d:
            return []
        if d.get("chat"):
            CHAT["id"] = int(d["chat"])
        return [dict(x, c={int(k): v for k, v in (x.get("c") or {}).items()}) for x in d.get("items") or []]
    from app.market.hub import hub
    return [{"id": i.id, "name": i.name, "payout": i.payout, "last": hub.last(i.id),
             "c": {tf: hub.candles(i.id, tf, 40) for tf in TFS}} for i in hub.list(None) if i.active]


async def price_at(inst: str, ts: float) -> Optional[float]:
    """Last live tick at or before ts, not older than 3 s (the pair's stream is kept on while its signal runs)."""
    from app.market.hub import hub
    se = hub.series.get(inst)
    if not se or not se.ticks:
        return None
    for t, p in reversed(se.ticks):
        if t <= ts:
            return p if ts - t <= float(os.getenv("ARTFS_TICK_TOL", "3")) else None
    return None


def watch(inst: Optional[str]) -> None:
    """Keep the live stream of the running signal's pair (1 of the broker's 4 streams); release the others."""
    from app.market.hub import hub
    for k in list(WATCHED):
        if k != inst:
            hub.pinned.discard(k)
            WATCHED.discard(k)
    if inst:
        hub.pinned.add(inst)
        WATCHED.add(inst)
        pr = getattr(hub, "provider", None)
        if pr is not None and hasattr(pr, "want"):
            asyncio.create_task(pr.want(inst))


WATCHED: set = set()


# ------------------------------------------------------------------ state
def _st() -> dict:
    try:
        return json.loads(journal.get_setting("artfs_state") or "{}")
    except Exception:  # noqa: BLE001
        return {}


def _save(s: dict) -> None:
    journal.set_setting("artfs_state", json.dumps(s))


# ------------------------------------------------------------------ the channel's own signal engine
# Independent from the Mini App: its own Heikin Ashi analysis on M1 / M3 / M5, trade times 5 / 10 / 15 seconds,
# its own entries resolved on real broker ticks. Nothing here touches the AUTO windows of the Mini App.
TFS = {180: "M3", 300: "M5"}
EXP_OF = {180: _i("ARTFS_EXP_M3", 3), 300: _i("ARTFS_EXP_M5", 5)}
MIN_PAYOUT = _i("ARTFS_MIN_PAYOUT", 85)          # only OTC pairs with a good payout
OTC_ONLY = os.getenv("ARTFS_OTC_ONLY", "true").lower() in ("1", "true", "yes", "on")
FORCE1, FORCE2 = _i("ARTFS_FORCE1", 15), _i("ARTFS_FORCE2", 25)   # idle seconds → softer filters, so the channel never goes quiet


def ha_candles(cs: list) -> list:
    out = []
    for k, c in enumerate(cs):
        o, h, l, cl = c[1], c[2], c[3], c[4]
        hc = (o + h + l + cl) / 4
        ho = (o + cl) / 2 if not out else (out[-1][0] + out[-1][3]) / 2
        out.append((ho, max(h, ho, hc), min(l, ho, hc), hc))
    return out


def ha_score(cs: list) -> Optional[tuple]:
    """(score, direction) from closed HA candles: a clean run of one colour, strong last body, no opposite wick."""
    if len(cs) < 12:
        return None
    ha = ha_candles(cs[:-1])                       # only closed candles
    col = [1 if c[3] > c[0] else -1 if c[3] < c[0] else 0 for c in ha]
    d = col[-1]
    if not d:
        return None
    run = 0
    for x in reversed(col):
        if x != d:
            break
        run += 1
    if run < 3 or run > 6 or sum(1 for x in col[-5:] if x == d) < 4:     # a clean run, but not an exhausted one
        return None
    o, h, l, c = ha[-1]
    rng = (h - l) or 1e-12
    body = abs(c - o) / rng
    wick_against = ((min(o, c) - l) if d > 0 else (h - max(o, c))) / rng
    if body < 0.45 or wick_against > 0.12:
        return None
    bodies = [abs(x[3] - x[0]) for x in ha[-12:-1]]
    avg = (sum(bodies) / len(bodies)) or 1e-12
    if abs(c - o) < 0.8 * avg:
        return None
    score = min(run, 5) * 2 + body * 4 + (1 - wick_against) * 2 + min(abs(c - o) / avg, 3)
    return score, ("BUY" if d > 0 else "SELL")


def ha_dir(cs: list) -> int:
    """Colour of the last CLOSED Heikin Ashi candle: 1 / -1 / 0."""
    if len(cs) < 4:
        return 0
    o, _, _, c = ha_candles(cs[:-1])[-1]
    return 1 if c > o else -1 if c < o else 0


HIGHER = {180: 300, 300: None}


async def find_signal(now: float, only: Optional[tuple] = None, min_score: Optional[float] = None, need_hi: bool = True) -> Optional[dict]:
    """Best HA setup over all pairs (or only=(inst, tf, dir) to re-check one). A higher timeframe must agree."""
    best = None
    for x in await market():
        if only and x["id"] != only[0]:
            continue
        if OTC_ONLY and not str(x["id"]).lower().endswith("_otc"):
            continue
        pay = float(x.get("payout") or 0)
        last = x.get("last")
        if pay < MIN_PAYOUT or not last or now - float(last[1]) > 180:     # Pocket: pairs without a live stream refresh by candles
            continue
        cs_all = x.get("c") or {}
        for tf in TFS:
            if only and tf != only[1]:
                continue
            r = ha_score(cs_all.get(tf) or [])
            if not r or (only and r[1] != only[2]) or r[0] < (MIN_SCORE if min_score is None else min_score):
                continue
            ls = LEARN.get(str(tf)) or [0, 0]
            if not only and need_hi and ls[0] + ls[1] >= 30 and ls[0] / (ls[0] + ls[1]) < 0.45:   # this timeframe loses live → rest it
                continue
            want = 1 if r[1] == "BUY" else -1
            hi = HIGHER[tf]
            if need_hi and hi and ha_dir(cs_all.get(hi) or []) != want:          # the bigger picture must point the same way
                continue
            if best is None or r[0] + pay / 100 > best[0]:
                best = (r[0] + pay / 100, x, tf, r[1])
    if not best:
        return None
    _, x, tf, d = best
    exp = EXP_OF[tf]
    first = (int(now) // 60 + 1) * 60
    if first - now < LEAD:
        first += 60
    step = max(15, -(-(exp + 12) // 5) * 5)
    return {"id": int(now), "inst": x["id"], "name": x["name"], "direction": d, "payout": float(x["payout"]), "expiry": exp,
            "tfs": tf, "factors": {"ha": {"tf": TFS[tf]}}, "plan": [first + k * step for k in range(ENTRIES)], "attempts": []}


async def resolve(w: dict, now: float) -> str:
    """Resolve the next due entry on real ticks → 'wait' | 'added' | 'stop' (no price)."""
    k = len(w["attempts"])
    if k >= len(w["plan"]):
        return "stop"
    t0, exp = w["plan"][k], int(w["expiry"])
    if now < t0 + exp + 3:
        return "wait"
    a, b = await price_at(w["inst"], t0), await price_at(w["inst"], t0 + exp)
    if a is None or b is None:
        if now < t0 + exp + 15:                             # the quote may still be on its way — ask again in a moment
            return "wait"                                   # (by time, not a counter: the state is reloaded every tick)
        log.warning("ARTFS entry %s %s: no price", k + 1, w["inst"])
        return "stop"
    r = "DRAW" if b == a else ("WIN" if (b > a) == (w["direction"] == "BUY") else "LOSS")
    w["attempts"].append({"i": k + 1, "entry_at": t0, "expires_at": t0 + exp, "entry_price": a, "exit_price": b, "result": r})
    return "added"


async def post_signal(s: dict, w: dict) -> None:
    mid = await photo("buy" if w["direction"] == "BUY" else "sell", cap_signal(w))
    s["cur"] = {"w": w, "mid": mid}
    s.pop("idle_since", None)
    s.pop("prep", None)
    log.info("ARTFS signal %s %s %s %s", w["inst"], w["direction"], trade_tag(w), [hms(t) for t in w["plan"]])
    _save(s)


async def step(s: dict, now: float) -> None:
    """One tick of the channel state machine."""
    day = datetime.fromtimestamp(now, KYIV).strftime("%Y-%m-%d")
    # 1. morning post (+ rules) once a day when the hours open
    hour = datetime.fromtimestamp(now, KYIV).hour
    mh = MORNING if h24() else max(FROM, MORNING if FROM <= MORNING < TO else FROM)
    if s.get("day") != day and hour >= mh and in_hours(now):
        s["day"] = day
        if hour >= mh + 3:                                    # started late in the day: no «good morning»
            s["next_warn"] = now + 60
            _save(s)
            return
        s["next_warn"] = now + 60                             # ARTUR channel: no morning / rules posts
        _save(s)
        return
    LEARN.clear()
    LEARN.update(s.get("learn") or {})
    cw = (s.get("cur") or {}).get("w") or {}
    if cw and now > float((cw.get("plan") or [now])[-1]) + int(cw.get("expiry") or 0) + 120:
        log.info("ARTFS stale signal %s dropped (bot restarted during it)", cw.get("inst"))
        s.pop("cur", None)
        s["next_scan"] = now
        _save(s)
    if s.get("prep") and now > float(s["prep"].get("at", now)) + 120:
        s.pop("prep", None)
        _save(s)
    watch(((s.get("cur") or {}).get("w") or {}).get("inst") or (s.get("prep") or {}).get("inst"))
    # 2. follow the published signal entry by entry
    cur = s.get("cur")
    if cur:
        w = cur["w"]
        r = await resolve(w, now)
        if r == "wait":
            return
        fin, *_ = result_of(w)
        if r == "stop" and not w["attempts"]:
            log.info("ARTFS signal %s skipped: no quote for entry 1 (restart) — signal post removed", w["inst"])
            if cur.get("mid"):                                    # no result possible → no orphan signal in the channel
                await _tg("deleteMessage", {"message_id": cur["mid"]})
            s.pop("cur")
            s["next_scan"] = now
            s["idle_since"] = now - FORCE2                        # post the next one right away
        elif r == "stop" and fin != "WIN":
            log.info("ARTFS window %s interrupted (no quote) after %d entries", w["inst"], len(w["attempts"]))
            s.pop("cur")
            s["next_scan"] = now + PAUSE
            s["idle_since"] = now
        elif fin == "WIN" or len(w["attempts"]) >= ENTRIES:
            c = cap_result(w)
            lr = s.setdefault("learn", {})                    # per timeframe: entries won / lost (live, this channel)
            k = str(w.get("tfs") or tf_of(w))
            e = lr.setdefault(k, [0, 0])
            e[0] += sum(1 for a in w["attempts"] if a["result"] == "WIN")
            e[1] += sum(1 for a in w["attempts"] if a["result"] == "LOSS")
            log.info("ARTFS result %s %s %s: %s · tf stats %s", w["inst"], w["direction"], trade_tag(w),
                     "".join({"WIN": "+", "LOSS": "-", "DRAW": "="}.get(a["result"], "?") for a in w["attempts"]), lr)
            if c:
                await photo("res_win" if c[0] in ("WIN", "DRAW") else "res_loss", c[1], reply_to=cur.get("mid"))
                await asyncio.sleep(2)
                await text("<blockquote><b>🗣 Checking new signal...</b></blockquote>")
                nw, nl = (1 if c[0] == "WIN" else 0), (1 if c[0] == "LOSS" else 0)   # one signal = one ➕ or one ➖
                al = s.setdefault("all", {"w": 0, "l": 0})
                al["w"] += nw
                al["l"] += nl
                td = s.setdefault("today", {})
                if td.get("d") != day:
                    td.clear()
                    td.update(d=day, w=0, l=0)
                td["w"] += nw
                td["l"] += nl
            s.pop("cur")
            s["next_scan"] = now + PAUSE
            s["idle_since"] = now
        _save(s)
        return
    if not in_hours(now):
        return
    # 2b. the pair was announced: after PREP seconds re-check the setup, then the signal with the direction
    pr = s.get("prep")
    if pr:
        if now < pr["at"]:
            return
        s.pop("prep")
        w = await find_signal(now, only=(pr["inst"], pr["tf"], pr["dir"]))
        if not w:
            s["idle_since"] = s.get("idle_since") or now
            s["next_scan"] = now                       # no silence: look for the next setup right away
            s["scan_at"] = 0
            log.info("ARTFS setup %s dropped on re-check", pr["inst"])
            _save(s)
            return
        await post_signal(s, w)
        return
    # 3. heads-up «signal within 5–35 minutes» + statistics, once per HACH_WARN_EVERY (default 1 h)
    if now - s.get("warn_at", 0) >= WARN_EVERY:                # statistics card once an hour
        await photo("stats", f"<blockquote><b>{stats_line(s, day)}</b></blockquote>")
        s["warn_at"] = now
        s["next_scan"] = now + 30
        _save(s)
        return
    # 4. non-stop: a short pause after every result, then the channel's own HA search → analysis + signal
    if now >= s.get("next_scan", 0):
        if now - s.get("scan_at", 0) < 5:
            return
        s["scan_at"] = now
        idle = now - float(s.setdefault("idle_since", now))
        if idle >= FORCE1:                                        # quiet too long → softer filters, post right away
            w = await find_signal(now, min_score=min(MIN_SCORE, 9.0))
            if not w and idle >= FORCE2:
                w = await find_signal(now, min_score=5.0, need_hi=False)
            if not w and idle >= FORCE2 + 10:
                w = await find_signal(now, min_score=0.0, need_hi=False)
            if w:
                log.info("ARTFS forced after %ds idle", int(idle))
                await post_signal(s, w)
            return
        w = await find_signal(now)
        if not w:
            return
        exp, tf = int(w["expiry"]), tf_of(w)
        s["exp"], s["tf"] = exp, tf
        amid = None                                               # ARTUR channel: no analysis post
        s["prep"] = {"inst": w["inst"], "tf": w["tfs"], "dir": w["direction"], "at": now + PREP, "mid": amid}
        log.info("ARTFS analysis %s %s — signal in %ss if the setup holds", w["inst"], TFS[w["tfs"]], PREP)
        _save(s)


async def wipe_channel(token: str) -> None:
    """One-time clean start (ARTFS_WIPE=<any new word>): delete the channel history the bot is allowed to delete
    (Telegram: messages younger than 48 h, bot needs «Delete messages») and reset the channel statistics."""
    if not token or journal.get_setting("artfs_wiped") == token:
        return
    m = await _tg("sendMessage", {"text": "🧹"})
    top = (m or {}).get("message_id")
    if not top:
        log.warning("ARTFS wipe: cannot post to the channel")
        return
    ok = fail = 0
    for start in range(1, top + 1, 100):
        ids = list(range(start, min(top, start + 99) + 1))
        r = await _tg("deleteMessages", {"message_ids": json.dumps(ids)})
        if r:
            ok += len(ids)
        else:
            fail += len(ids)
        await asyncio.sleep(0.4)
    _save({})
    journal.set_setting("artfs_wiped", token)
    log.info("ARTFS wipe done: ids 1..%s processed (%s batches ok, %s ids failed) · stats reset", top, ok // 100 + 1, fail)


async def loop() -> None:
    await asyncio.sleep(40 if not MAIN_URL else 5)
    log.info("ARTFS on: %s, %s signals/day, up to %d entries, stake %d%%",
             "24/7" if h24() else f"{FROM:02d}-{TO:02d} Kyiv", PER_DAY, ENTRIES, STAKE)
    try:
        await wipe_channel((os.getenv("ARTFS_WIPE") or "").strip())
    except Exception as e:  # noqa: BLE001
        log.warning("ARTFS wipe: %s", e)
    while True:
        try:
            if _on() and journal.get_setting("artfs_off") != "1":
                if not chat_id() and MAIN_URL:
                    await market()                      # learns the channel id from the Mini App server
                if chat_id():
                    await step(_st(), time.time())
        except Exception as e:  # noqa: BLE001
            log.warning("ARTFS step: %s", e)
        await asyncio.sleep(3)
