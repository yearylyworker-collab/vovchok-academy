"""POSTER — a separate Telegram bot for the admin's own channel posts (needs POSTER_BOT_TOKEN).

Send it a photo / video / text (with formatting) → add buttons → pick the channel(s) → it publishes.
«Рамка» mode: the photo is shown as a large link preview with a coloured bar and a header line on top
(the preview page /p/<id> lives on this server), the text goes under it, buttons can be red / blue / green.
The bot remembers every channel where it was made an admin. Only ADMIN_IDS (+ POSTER_ADMINS) can use it.
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Optional

import httpx
from starlette.requests import Request
from starlette.responses import FileResponse, HTMLResponse, PlainTextResponse

from app import config, journal

log = logging.getLogger("poster")
TOKEN = os.getenv("POSTER_BOT_TOKEN", "").strip()
API = f"https://api.telegram.org/bot{TOKEN}"
DIR = Path(os.path.dirname(os.path.abspath(config.DB_PATH))) / "poster"
COLORS = {"красн": "danger", "red": "danger", "син": "primary", "blue": "primary", "голуб": "primary",
          "зел": "success", "green": "success"}
HELP = ("🖼 <b>Бот для постов</b>\n\n"
        "1️⃣ Пришли <b>фото с подписью</b> (или видео / просто текст). Форматирование (жирный, цитаты, ссылки) сохраняется.\n"
        "2️⃣ Пришли <b>кнопки</b> — каждая с новой строки:\n"
        "<code>Создать аккаунт | https://ссылка | красная</code>\n"
        "<code>Подписаться | https://t.me/... | синяя</code>\n"
        "Цвет: красная / синяя / зелёная (можно не писать). Без кнопок — /skip\n"
        "3️⃣ Я покажу превью → жми, в какой канал отправить.\n\n"
        "🖼 <b>Рамка</b> — фото в рамке с цветной полоской и заголовком сверху, текст под ним. Включается кнопкой в превью.\n"
        "Заголовок рамки: <code>/title 👑 ARTUR TRADE 📈</code>\n\n"
        "📢 Каналы: добавь меня админом в канал (право «Публикация сообщений») — я запомню его сам. Список: /channels\n"
        "Начать заново: /cancel")

_c: Optional[httpx.AsyncClient] = None
DRAFT: dict = {}


def _admins() -> set:
    ids = set(config.ADMIN_IDS or [])
    for x in re.findall(r"\d+", os.getenv("POSTER_ADMINS", "")):
        ids.add(int(x))
    return ids


def _base() -> str:
    u = os.getenv("PUBLIC_URL") or os.getenv("RAILWAY_PUBLIC_DOMAIN") or ""
    u = u.strip().rstrip("/")
    return u if not u or u.startswith("http") else "https://" + u


def channels() -> dict:
    try:
        return json.loads(journal.get_setting("poster_channels") or "{}")
    except Exception:  # noqa: BLE001
        return {}


def _set_channels(d: dict) -> None:
    journal.set_setting("poster_channels", json.dumps(d, ensure_ascii=False))


def _title() -> str:
    return journal.get_setting("poster_title") or "ARTUR TRADE 📈"


async def call(method: str, **p):
    global _c
    _c = _c or httpx.AsyncClient(timeout=40)
    try:
        r = await _c.post(f"{API}/{method}", json=p)
        d = r.json()
        if not d.get("ok"):
            log.warning("poster %s: %s", method, d.get("description"))
            return None, d.get("description", "")
        return d.get("result"), ""
    except Exception as e:  # noqa: BLE001
        log.warning("poster %s failed: %s", method, e)
        return None, str(e)


async def say(chat: int, text: str, kb=None):
    p = {"chat_id": chat, "text": text, "parse_mode": "HTML", "link_preview_options": {"is_disabled": True}}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return (await call("sendMessage", **p))[0]


# ------------------------------------------------------------------ preview page --
async def page(request: Request):
    pid = re.sub(r"[^0-9a-z]", "", request.path_params.get("pid", ""))
    meta = DIR / f"{pid}.json"
    if not meta.exists():
        return PlainTextResponse("not found", status_code=404)
    m = json.loads(meta.read_text("utf-8"))
    t = html.escape(m.get("title") or "")
    img = f"{_base()}/p/{pid}.jpg"
    return HTMLResponse(f'<!doctype html><html><head><meta charset="utf-8"><title>{t}</title>'
                        f'<meta property="og:site_name" content="{t}"><meta property="og:type" content="website">'
                        f'<meta property="og:image" content="{img}"><meta name="twitter:card" content="summary_large_image">'
                        f'<meta name="twitter:image" content="{img}"></head><body><img src="{img}" style="max-width:100%"></body></html>')


async def image(request: Request):
    pid = re.sub(r"[^0-9a-z]", "", request.path_params.get("pid", ""))
    f = DIR / f"{pid}.jpg"
    return FileResponse(str(f), media_type="image/jpeg") if f.exists() else PlainTextResponse("not found", status_code=404)


async def _save_photo(file_id: str, title: str) -> Optional[str]:
    r, _ = await call("getFile", file_id=file_id)
    if not r or not r.get("file_path"):
        return None
    try:
        b = (await _c.get(f"https://api.telegram.org/file/bot{TOKEN}/{r['file_path']}")).content
    except Exception as e:  # noqa: BLE001
        log.warning("poster download: %s", e)
        return None
    DIR.mkdir(parents=True, exist_ok=True)
    pid = format(int(time.time() * 1000), "x")
    (DIR / f"{pid}.jpg").write_bytes(b)
    (DIR / f"{pid}.json").write_text(json.dumps({"title": title}, ensure_ascii=False), "utf-8")
    return pid


# ------------------------------------------------------------------ composing --
def parse_buttons(text: str) -> list:
    rows = []
    for line in (text or "").splitlines():
        parts = [x.strip() for x in line.split("|")]
        if len(parts) < 2 or not parts[0] or not re.match(r"https?://|tg://", parts[1]):
            continue
        b = {"text": parts[0], "url": parts[1]}
        col = (parts[2] if len(parts) > 2 else "").lower()
        st = next((v for k, v in COLORS.items() if col.startswith(k)), None)
        if st:
            b["style"] = st
        rows.append([b])
    return rows


def _strip(rows: list) -> list:
    return [[{k: v for k, v in b.items() if k != "style"} for b in r] for r in rows]


async def send_post(chat, d: dict):
    """Send the draft to a chat. Falls back without colours / custom emoji if Telegram refuses them."""
    rows = d.get("buttons") or []
    ents = d.get("entities") or []
    text = d.get("text") or ""
    for attempt in range(3):
        p = {"chat_id": chat}
        if rows:
            p["reply_markup"] = {"inline_keyboard": rows}
        if d["kind"] == "photo" and d.get("frame") and d.get("pid") and text:
            p.update(text=text, entities=ents, link_preview_options={
                "url": f"{_base()}/p/{d['pid']}", "prefer_large_media": True, "show_above_text": True})
            m = "sendMessage"
        elif d["kind"] in ("photo", "video", "animation"):
            p.update({d["kind"]: d["file_id"], "caption": text, "caption_entities": ents})
            m = {"photo": "sendPhoto", "video": "sendVideo", "animation": "sendAnimation"}[d["kind"]]
        else:
            p.update(text=text, entities=ents, link_preview_options={"is_disabled": True})
            m = "sendMessage"
        r, err = await call(m, **p)
        if r:
            return r, ""
        e = err.lower()
        if "style" in e or "button" in e:
            rows = _strip(rows)
        elif "emoji" in e or "entit" in e:
            ents = [x for x in ents if x.get("type") != "custom_emoji"]
        else:
            return None, err
    return None, err


async def preview(uid: int) -> None:
    d = DRAFT[uid]
    await say(uid, "👀 <b>Превью поста:</b>")
    r, err = await send_post(uid, d)
    if not r:
        await say(uid, f"⚠️ Не получилось показать превью: {html.escape(err)}\n/cancel — начать заново")
        return
    chs = channels()
    kb = [[{"text": f"📤 {v}", "callback_data": f"pub:{k}"}] for k, v in chs.items()]
    if len(chs) > 1:
        kb.append([{"text": "📤 Во все каналы", "callback_data": "pub:all"}])
    if d["kind"] == "photo":
        kb.append([{"text": ("🖼 Рамка: ВКЛ — выключить" if d.get("frame") else "🖼 Рамка: выкл — включить"), "callback_data": "frame"}])
    kb.append([{"text": "❌ Отмена", "callback_data": "cancel"}])
    note = "" if chs else "\n\n⚠️ Каналов пока нет — добавь меня админом в канал, и кнопка появится (потом нажми /preview)."
    await say(uid, "Куда отправить?" + note, kb)


# ------------------------------------------------------------------ updates --
async def on_message(m: dict) -> None:
    uid = m.get("from", {}).get("id")
    if m.get("chat", {}).get("type") != "private" or uid not in _admins():
        if m.get("chat", {}).get("type") == "private":
            await say(m["chat"]["id"], "Этот бот только для администратора.")
        return
    text = m.get("text") or ""
    if text.startswith("/start") or text.startswith("/help"):
        await say(uid, HELP)
        return
    if text.startswith("/cancel"):
        DRAFT.pop(uid, None)
        await say(uid, "Черновик удалён. Присылай новый пост.")
        return
    if text.startswith("/title"):
        t = text[6:].strip()
        if t:
            journal.set_setting("poster_title", t)
        await say(uid, f"Заголовок рамки: <b>{html.escape(_title())}</b>\nИзменить: <code>/title 👑 Название</code>")
        return
    if text.startswith("/channels"):
        chs = channels()
        await say(uid, ("📢 <b>Каналы:</b>\n" + "\n".join(f"• {html.escape(v)} <code>{k}</code>" for k, v in chs.items()))
                  if chs else "Каналов нет. Добавь меня админом в канал с правом «Публикация сообщений».")
        return
    if text.startswith("/preview") and uid in DRAFT:
        await preview(uid)
        return
    d = DRAFT.get(uid)
    if d and d.get("step") == "buttons" and (text or "").strip():
        if not text.startswith("/skip"):
            d["buttons"] = parse_buttons(text)
            if not d["buttons"]:
                await say(uid, "Не понял кнопки. Формат: <code>Текст | https://ссылка | красная</code> — каждая с новой строки. Без кнопок — /skip")
                return
        d["step"] = "ready"
        await preview(uid)
        return
    kind = next((k for k in ("photo", "video", "animation") if m.get(k)), None)
    if kind or text:
        d = {"kind": kind or "text", "text": m.get("caption") or text,
             "entities": m.get("caption_entities") or m.get("entities") or [], "step": "buttons", "frame": False}
        if kind == "photo":
            d["file_id"] = m["photo"][-1]["file_id"]
            d["pid"] = await _save_photo(d["file_id"], _title()) if _base() else None
            d["frame"] = bool(d["pid"] and d["text"])
        elif kind:
            d["file_id"] = m[kind]["file_id"]
        DRAFT[uid] = d
        await say(uid, "✅ Принял. Теперь <b>кнопки</b> — каждая с новой строки:\n"
                       "<code>Создать аккаунт | https://ссылка | красная</code>\n"
                       "<code>Подписаться на канал | https://t.me/... | синяя</code>\n\nБез кнопок — /skip")


async def on_callback(q: dict) -> None:
    uid, data = q["from"]["id"], q.get("data", "")
    await call("answerCallbackQuery", callback_query_id=q["id"])
    if uid not in _admins():
        return
    d = DRAFT.get(uid)
    if data == "cancel":
        DRAFT.pop(uid, None)
        await say(uid, "Отменено.")
        return
    if not d:
        await say(uid, "Черновика нет — пришли новый пост.")
        return
    if data == "frame":
        d["frame"] = not d.get("frame")
        if d["frame"] and not d.get("text"):
            d["frame"] = False
            await say(uid, "Для рамки нужен текст под фото — пришли фото с подписью.")
            return
        if d["frame"] and d.get("pid"):                               # header text may have changed
            (DIR / f"{d['pid']}.json").write_text(json.dumps({"title": _title()}, ensure_ascii=False), "utf-8")
        await preview(uid)
        return
    if data.startswith("pub:"):
        chs = channels()
        targets = list(chs) if data == "pub:all" else [data[4:]]
        out = []
        for ch in targets:
            r, err = await send_post(int(ch), d)
            out.append(f"{'✅' if r else '⚠️'} {html.escape(chs.get(ch, ch))}" + ("" if r else f" — {html.escape(err)}"))
        await say(uid, "\n".join(out) + "\n\nПрисылай следующий пост 👇")
        DRAFT.pop(uid, None)


async def on_member(u: dict) -> None:
    """The bot was added to / removed from a channel → remember it."""
    ch = u.get("chat", {})
    if ch.get("type") not in ("channel", "supergroup"):
        return
    st = (u.get("new_chat_member") or {}).get("status")
    chs = channels()
    k = str(ch["id"])
    if st == "administrator":
        chs[k] = ch.get("title") or k
        _set_channels(chs)
        who = (u.get("from") or {}).get("id")
        if who in _admins():
            await say(who, f"📢 Канал добавлен: <b>{html.escape(chs[k])}</b>")
    elif st in ("left", "kicked", "member") and k in chs:
        chs.pop(k)
        _set_channels(chs)


async def loop() -> None:
    if not TOKEN:
        return
    await call("setMyCommands", commands=[{"command": "start", "description": "Как делать пост"},
                                          {"command": "channels", "description": "Мои каналы"},
                                          {"command": "title", "description": "Заголовок рамки"},
                                          {"command": "cancel", "description": "Удалить черновик"}])
    log.info("POSTER bot on (channels: %d, preview pages: %s)", len(channels()), _base() or "off")
    off = 0
    while True:
        try:
            r = await _c.get(f"{API}/getUpdates", params={"offset": off, "timeout": 30,
                                                         "allowed_updates": json.dumps(["message", "callback_query", "my_chat_member"])})
            for u in r.json().get("result", []):
                off = u["update_id"] + 1
                try:
                    if "message" in u:
                        await on_message(u["message"])
                    elif "callback_query" in u:
                        await on_callback(u["callback_query"])
                    elif "my_chat_member" in u:
                        await on_member(u["my_chat_member"])
                except Exception as e:  # noqa: BLE001
                    log.exception("poster update failed: %s", e)
        except Exception as e:  # noqa: BLE001
            log.warning("poster polling: %s", e)
            await asyncio.sleep(3)
